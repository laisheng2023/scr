module lcd_driver(
    input  clk,                    // 27MHz时钟
    input  [3:0] group,            // 来自键盘的音组 (2-5)
    input  [2:0] note,             // 来自键盘的音符 (1-7)
    input  group_valid,            // 音组是否有效
    input  note_valid,
    
    // LCD 接口
    output cs,
    output dc,
    output scl,
    output sda,
    output rst
);

    // ========== 屏幕显示参数 ==========
    localparam LCD_W = 8'd132;
    localparam LCD_H = 8'd162;
    
    localparam COLOR_RED    = 16'hF800;
    localparam COLOR_WHITE  = 16'hFFFF;
    localparam COLOR_BLUE   = 16'h001F;
    localparam COLOR_GREEN  = 16'h07E0;
    localparam COLOR_BLACK  = 16'h0000;
    localparam COLOR_YELLOW = 16'hFFE0;
    
    localparam IDLE  = 4'd0;
    localparam MAIN  = 4'd1;
    localparam INIT  = 4'd2;
    localparam SCAN  = 4'd3;
    localparam WRITE = 4'd4;
    localparam DELAY = 4'd5;
    
    localparam LOW  = 1'b0;
    localparam HIGH = 1'b1;
    
    // ========== 寄存器 ==========
    reg [3:0] state;
    reg [3:0] state_back;
    reg [7:0] x_cnt;
    reg [7:0] y_cnt;
    reg [5:0] cnt_write;
    reg [23:0] cnt_delay;
    reg [23:0] num_delay;
    reg [15:0] cnt;
    reg [2:0] cnt_main;
    reg [2:0] cnt_init;
    reg [3:0] cnt_scan;
    reg [8:0] data_reg;
    reg high_word;
    reg [1:0] clk_div;
    
    reg cs_r;
    reg dc_r;
    reg scl_r;
    reg sda_r;
    reg rst_r;
    
    reg show_pixel;
    reg [15:0] pixel_color;
    
    wire clk_spi;
    assign clk_spi = clk_div[0];
    
    // ========== 初始化命令 ==========
    reg [8:0] reg_init [0:5];
    reg [8:0] reg_setxy [0:10];
    
    // ========== 点阵数据 ==========
    reg [0:63] yanzoumoshi [0:15];
    reg [0:63] jianzu [0:15];
    reg [0:63] yinliang [0:15];
//    reg [0:31] maohao [0:15];
    reg [0:63] yingao [0:15];
    reg [0:63] A [0:15];
    reg [0:63] B [0:15];
    reg [0:63] C [0:15];
    reg [0:63] D [0:15];
    reg [0:63] F [0:15];
reg [0:15] ling [0:15];      // 5
    reg [0:15] er [0:15];      // 2
reg [0:15] san [0:15];     // 3
reg [0:15] si [0:15];      // 4
reg [0:15] wu [0:15];      // 5
reg [0:15] yi [0:15];      // 1
reg [0:15] liu [0:15];     // 6
reg [0:15] qi [0:15];      // 7
(* keep = "true" *)reg [31:0] Do [0:15];
(* DONT_TOUCH = "true" *)reg [31:0] Re [0:15];
(* keep = "true" *)reg [31:0] Mi [0:15];
(* keep = "true" *)reg [31:0] Fa [0:15];
(* keep = "true" *)reg [31:0] So [0:15];
(* keep = "true" *)reg [31:0] La [0:15];
(* keep = "true" *)reg [31:0] Si [0:15];
//(* keep = "true" *)reg [0:127] yidaoqi [0:15];
    // ========== 点阵演奏模式数据 ==========
    initial begin
        yanzoumoshi[0]  = 64'h0080010011100048;
        yanzoumoshi[1]  = 64'h2040010011100044;
        yanzoumoshi[2]  = 64'h17fc7ffc17fc0044;
        yanzoumoshi[3]  = 64'h1404010011100040;
        yanzoumoshi[4]  = 64'h80003ff8fc00fffe;
        yanzoumoshi[5]  = 64'h43f8020013f80040;
        yanzoumoshi[6]  = 64'h4040fffe32080040;
        yanzoumoshi[7]  = 64'h13f804403bf83e40;
        yanzoumoshi[8]  = 64'h1248082056080840;
        yanzoumoshi[9]  = 64'h23f837d853f80840;
        yanzoumoshi[10] = 64'he248c10690400820;
        yanzoumoshi[11] = 64'h23f81ff017fc0822;
        yanzoumoshi[12] = 64'h2000010010a00f12;
        yanzoumoshi[13] = 64'h211002c01110780a;
        yanzoumoshi[14] = 64'h22080c3012082006;
        yanzoumoshi[15] = 64'h0404300814060002;
    end

    initial begin
        jianzu[0]  = 64'h2010100000000000;
        jianzu[1]  = 64'h201011f800000000;
        jianzu[2]  = 64'h3b7c210800000000;
        jianzu[3]  = 64'h2114210800000000;
        jianzu[4]  = 64'h41fe490800000000;
        jianzu[5]  = 64'h7a14f9f800000000;
        jianzu[6]  = 64'ha27c110800000000;
        jianzu[7]  = 64'h2710210800000000;
        jianzu[8]  = 64'hf97c410800000000;
        jianzu[9]  = 64'h2510f9f830000000;
        jianzu[10] = 64'h25fe410830000000;
        jianzu[11] = 64'h2210010800000000;
        jianzu[12] = 64'h2a10190830000000;
        jianzu[13] = 64'h3500e10830000000;
        jianzu[14] = 64'h28fe47fe00000000;
        jianzu[15] = 64'h0000000000000000;
    end

// ========== 点阵音量数据 (16行 x 32列) ==========
initial begin
    yinliang[0]  = 64'h0200000000000000;
    yinliang[1]  = 64'h01001ff000000000;
    yinliang[2]  = 64'h3ff8101000000000;
    yinliang[3]  = 64'h00001ff000000000;
    yinliang[4]  = 64'h0820101000000000;
    yinliang[5]  = 64'h0440fffe00000000;
    yinliang[6]  = 64'hfffe000000000000;
    yinliang[7]  = 64'h00001ff000000000;
    yinliang[8]  = 64'h1ff0111000000000;
    yinliang[9]  = 64'h10101ff030000000;
    yinliang[10] = 64'h1010111030000000;
    yinliang[11] = 64'h1ff01ff000000000;
    yinliang[12] = 64'h1010010030000000;
    yinliang[13] = 64'h10101ff030000000;
    yinliang[14] = 64'h1ff0010000000000;
    yinliang[15] = 64'h10107ffc00000000;
end

    initial begin
        yingao[0]  = 64'h0200020000000000;
        yingao[1]  = 64'h0100010000000000;
        yingao[2]  = 64'h3ff8fffe00000000;
        yingao[3]  = 64'h0000000000000000;
        yingao[4]  = 64'h08200fe000000000;
        yingao[5]  = 64'h0440082000000000;
        yingao[6]  = 64'hfffe082000000000;
        yingao[7]  = 64'h00000fe000000000;
        yingao[8]  = 64'h1ff0000000000000;
        yingao[9]  = 64'h10107ffc30000000;
        yingao[10] = 64'h1010400430000000;
        yingao[11] = 64'h1ff04fe400000000;
        yingao[12] = 64'h1010482430000000;
        yingao[13] = 64'h1010482430000000;
        yingao[14] = 64'h1ff04fe400000000;
        yingao[15] = 64'h1010400c00000000;
    end

    initial begin
        A[0]  = 64'h0000000000001000;
        A[1]  = 64'h00000000000011f8;
        A[2]  = 64'h0000000000002108;
        A[3]  = 64'h100000003ff82108;
        A[4]  = 64'h1000000000004908;
        A[5]  = 64'h180000000000f9f8;
        A[6]  = 64'h2800000000001108;
        A[7]  = 64'h2800000000002108;
        A[8]  = 64'h2400000000004108;
        A[9]  = 64'h3c0000300000f9f8;
        A[10] = 64'h4400003000004108;
        A[11] = 64'h4200000000000108;
        A[12] = 64'h42000030fffe1908;
        A[13] = 64'he70000300000e108;
        A[14] = 64'h00000000000047fe;
        A[15] = 64'h0000000000000000;
    end

    initial begin
        B[0]  = 64'h0000000000001000;
        B[1]  = 64'h00000000000011f8;
        B[2]  = 64'h000000007ffc2108;
        B[3]  = 64'hf800000000002108;
        B[4]  = 64'h4400000000004908;
        B[5]  = 64'h440000000000f9f8;
        B[6]  = 64'h4400000000001108;
        B[7]  = 64'h780000003ff82108;
        B[8]  = 64'h4400000000004108;
        B[9]  = 64'h420000300000f9f8;
        B[10] = 64'h4200003000004108;
        B[11] = 64'h4200000000000108;
        B[12] = 64'h4400003000001908;
        B[13] = 64'hf8000030fffe6108;
        B[14] = 64'h00000000000047fe;
        B[15] = 64'h0000000000000000;
    end

    initial begin
        C[0]  = 64'h0000000000001000;
        C[1]  = 64'h00000000000011f8;
        C[2]  = 64'h000000007ffc2108;
        C[3]  = 64'h3e00000044442108;
        C[4]  = 64'h4200000044444908;
        C[5]  = 64'h420000004444f9f8;
        C[6]  = 64'h8000000044441108;
        C[7]  = 64'h8000000044442108;
        C[8]  = 64'h8000000048444108;
        C[9]  = 64'h80000030483cf9f8;
        C[10] = 64'h8000003050044108;
        C[11] = 64'h4200000060040108;
        C[12] = 64'h4400003040041908;
        C[13] = 64'h380000307ffce108;
        C[14] = 64'h00000000400447fe;
        C[15] = 64'h0000000000000000;
    end

    initial begin
        D[0]  = 64'h0000000000001000;
        D[1]  = 64'h000000007ffc11f8;
        D[2]  = 64'h0000000002002108;
        D[3]  = 64'hf800000002002108;
        D[4]  = 64'h4400000002004908;
        D[5]  = 64'h420000000200f9f8;
        D[6]  = 64'h420000003ff01108;
        D[7]  = 64'h4200000004102108;
        D[8]  = 64'h4200000004104108;
        D[9]  = 64'h420000300410f9f8;
        D[10] = 64'h4200003004104108;
        D[11] = 64'h4200000008100108;
        D[12] = 64'h4400003008101908;
        D[13] = 64'hf80000300810e108;
        D[14] = 64'h00000000fffe47fe;
        D[15] = 64'h0000000000000000;
    end

    initial begin
        F[0]  = 64'h0000000000080000;
        F[1]  = 64'h00000000203c3ff8;
        F[2]  = 64'h0000000013c02008;
        F[3]  = 64'hfc00000012002008;
        F[4]  = 64'h42000000020027c8;
        F[5]  = 64'h4800000003fc2448;
        F[6]  = 64'h48000000f2042448;
        F[7]  = 64'h7800000012882448;
        F[8]  = 64'h4800000012502448;
        F[9]  = 64'h4800003012202448;
        F[10] = 64'h40000030125027c8;
        F[11] = 64'h4000000014882008;
        F[12] = 64'h4000003015042008;
        F[13] = 64'he000003028003ff8;
        F[14] = 64'h0000000047fe2008;
        F[15] = 64'h0000000000000000;
    end
initial begin
    ling[0]  = 16'h0000;
    ling[1]  = 16'h0000;
    ling[2]  = 16'h0000;
    ling[3]  = 16'h1800;
    ling[4]  = 16'h2400;
    ling[5]  = 16'h4200;
    ling[6]  = 16'h4200;
    ling[7]  = 16'h4200;
    ling[8]  = 16'h4200;
    ling[9]  = 16'h4200;
    ling[10] = 16'h4200;
    ling[11] = 16'h4200;
    ling[12] = 16'h2400;
    ling[13] = 16'h1800;
    ling[14] = 16'h0000;
    ling[15] = 16'h0000;
end
// ========== 点阵1数据 (16行 x 16列) 原始 ==========
initial begin
    yi[0]  = 16'h0000;
    yi[1]  = 16'h0000;
    yi[2]  = 16'h0000;
    yi[3]  = 16'h0800;
    yi[4]  = 16'h3800;
    yi[5]  = 16'h0800;
    yi[6]  = 16'h0800;
    yi[7]  = 16'h0800;
    yi[8]  = 16'h0800;
    yi[9]  = 16'h0800;
    yi[10] = 16'h0800;
    yi[11] = 16'h0800;
    yi[12] = 16'h0800;
    yi[13] = 16'h3e00;
    yi[14] = 16'h0000;
    yi[15] = 16'h0000;
end

// ========== 点阵2数据 (16行 x 16列) 原始 ==========
initial begin
    er[0]  = 16'h0000;
    er[1]  = 16'h0000;
    er[2]  = 16'h0000;
    er[3]  = 16'h3c00;
    er[4]  = 16'h4200;
    er[5]  = 16'h4200;
    er[6]  = 16'h0200;
    er[7]  = 16'h0400;
    er[8]  = 16'h0800;
    er[9]  = 16'h1000;
    er[10] = 16'h2000;
    er[11] = 16'h4200;
    er[12] = 16'h7e00;
    er[13] = 16'h0000;
    er[14] = 16'h0000;
    er[15] = 16'h0000;
end

// ========== 点阵3数据 (16行 x 16列) 原始 ==========
initial begin
    san[0]  = 16'h0000;
    san[1]  = 16'h0000;
    san[2]  = 16'h0000;
    san[3]  = 16'h3c00;
    san[4]  = 16'h4200;
    san[5]  = 16'h4200;
    san[6]  = 16'h0200;
    san[7]  = 16'h0400;
    san[8]  = 16'h1800;
    san[9]  = 16'h0400;
    san[10] = 16'h0200;
    san[11] = 16'h4200;
    san[12] = 16'h4200;
    san[13] = 16'h3c00;
    san[14] = 16'h0000;
    san[15] = 16'h0000;
end

// ========== 点阵4数据 (16行 x 16列) 原始 ==========
initial begin
    si[0]  = 16'h0000;
    si[1]  = 16'h0000;
    si[2]  = 16'h0000;
    si[3]  = 16'h0400;
    si[4]  = 16'h0c00;
    si[5]  = 16'h0c00;
    si[6]  = 16'h1400;
    si[7]  = 16'h2400;
    si[8]  = 16'h2400;
    si[9]  = 16'h4400;
    si[10] = 16'h7f00;
    si[11] = 16'h0400;
    si[12] = 16'h0400;
    si[13] = 16'h1f00;
    si[14] = 16'h0000;
    si[15] = 16'h0000;
end

// ========== 点阵5数据 (16行 x 16列) 原始 ==========
initial begin
    wu[0]  = 16'h0000;
    wu[1]  = 16'h0000;
    wu[2]  = 16'h0000;
    wu[3]  = 16'h7e00;
    wu[4]  = 16'h4000;
    wu[5]  = 16'h4000;
    wu[6]  = 16'h4000;
    wu[7]  = 16'h7800;
    wu[8]  = 16'h4400;
    wu[9]  = 16'h0200;
    wu[10] = 16'h0200;
    wu[11] = 16'h4200;
    wu[12] = 16'h4400;
    wu[13] = 16'h3800;
    wu[14] = 16'h0000;
    wu[15] = 16'h0000;
end



initial begin
    Do[0]  = 32'h00000000;
    Do[1]  = 32'h00000000;
    Do[2]  = 32'h00000000;
    Do[3]  = 32'hf8000000;
    Do[4]  = 32'h44000000;
    Do[5]  = 32'h42000000;
    Do[6]  = 32'h42000000;
    Do[7]  = 32'h4203c000;
    Do[8]  = 32'h42042000;
    Do[9]  = 32'h42042000;
    Do[10] = 32'h42042000;
    Do[11] = 32'h42042000;
    Do[12] = 32'h44042000;
    Do[13] = 32'hf803c000;
    Do[14] = 32'h00000000;
    Do[15] = 32'h00000000;
end
initial begin
    Re[0]  = 32'h00000000;
    Re[1]  = 32'h00000000;
    Re[2]  = 32'h00000000;
    Re[3]  = 32'hfc000000;
    Re[4]  = 32'h42000000;
    Re[5]  = 32'h42000000;
    Re[6]  = 32'h42000000;
    Re[7]  = 32'h7c03c000;
    Re[8]  = 32'h48042000;
    Re[9]  = 32'h48042000;
    Re[10] = 32'h4407e000;
    Re[11] = 32'h44040000;
    Re[12] = 32'h42042000;
    Re[13] = 32'he303c000;
    Re[14] = 32'h00000000;
    Re[15] = 32'h00000000;
end
initial begin
    Mi[0]  = 32'h00000000;
    Mi[1]  = 32'h00000000;
    Mi[2]  = 32'h00000000;
    Mi[3]  = 32'hee030000;
    Mi[4]  = 32'h6c030000;
    Mi[5]  = 32'h6c000000;
    Mi[6]  = 32'h6c000000;
    Mi[7]  = 32'h6c070000;
    Mi[8]  = 32'h6c010000;
    Mi[9]  = 32'h54010000;
    Mi[10] = 32'h54010000;
    Mi[11] = 32'h54010000;
    Mi[12] = 32'h54010000;
    Mi[13] = 32'hd607c000;
    Mi[14] = 32'h00000000;
    Mi[15] = 32'h00000000;
end
initial begin
    Fa[0]  = 32'h00000000;
    Fa[1]  = 32'h00000000;
    Fa[2]  = 32'h00000000;
    Fa[3]  = 32'hfc000000;
    Fa[4]  = 32'h42000000;
    Fa[5]  = 32'h48000000;
    Fa[6]  = 32'h48000000;
    Fa[7]  = 32'h78038000;
    Fa[8]  = 32'h48044000;
    Fa[9]  = 32'h4800c000;
    Fa[10] = 32'h40034000;
    Fa[11] = 32'h40044000;
    Fa[12] = 32'h4004c000;
    Fa[13] = 32'he0036000;
    Fa[14] = 32'h00000000;
    Fa[15] = 32'h00000000;
end
initial begin
    So[0]  = 32'h00000000;
    So[1]  = 32'h00000000;
    So[2]  = 32'h00000000;
    So[3]  = 32'h3e000000;
    So[4]  = 32'h42000000;
    So[5]  = 32'h42000000;
    So[6]  = 32'h40000000;
    So[7]  = 32'h2003c000;
    So[8]  = 32'h18042000;
    So[9]  = 32'h04042000;
    So[10] = 32'h02042000;
    So[11] = 32'h42042000;
    So[12] = 32'h42042000;
    So[13] = 32'h7c03c000;
    So[14] = 32'h00000000;
    So[15] = 32'h00000000;
end
initial begin
    La[0]  = 32'h00000000;
    La[1]  = 32'h00000000;
    La[2]  = 32'h00000000;
    La[3]  = 32'he0000000;
    La[4]  = 32'h40000000;
    La[5]  = 32'h40000000;
    La[6]  = 32'h40000000;
    La[7]  = 32'h40038000;
    La[8]  = 32'h40044000;
    La[9]  = 32'h4000c000;
    La[10] = 32'h40034000;
    La[11] = 32'h40044000;
    La[12] = 32'h4204c000;
    La[13] = 32'hfe036000;
    La[14] = 32'h00000000;
    La[15] = 32'h00000000;
end
initial begin
    Si[0]  = 32'h00000000;
    Si[1]  = 32'h00000000;
    Si[2]  = 32'h00000000;
    Si[3]  = 32'h3e030000;
    Si[4]  = 32'h42030000;
    Si[5]  = 32'h42000000;
    Si[6]  = 32'h40000000;
    Si[7]  = 32'h20070000;
    Si[8]  = 32'h18010000;
    Si[9]  = 32'h04010000;
    Si[10] = 32'h02010000;
    Si[11] = 32'h42010000;
    Si[12] = 32'h42010000;
    Si[13] = 32'h7c07c000;
    Si[14] = 32'h00000000;
    Si[15] = 32'h00000000;
end
// ========== 点阵一倒起数据 (16行 x 128列) ==========
//initial begin
//    yidaoqi[0]  = 128'h00000000000000000000000000000000;
//    yidaoqi[1]  = 128'h00000000000000000000000000000000;
//    yidaoqi[2]  = 128'h00000000000000000000000000000000;
//    yidaoqi[3]  = 128'h000008003c003c0004007e0018007e00;
//    yidaoqi[4]  = 128'h00003800420042000c00400024004200;
//    yidaoqi[5]  = 128'h00000800420042000c00400040000400;
//    yidaoqi[6]  = 128'h00000800420002001400400040000400;
//    yidaoqi[7]  = 128'h0000080002000400240078005c000800;
//    yidaoqi[8]  = 128'h00000800040018002400440062000800;
//    yidaoqi[9]  = 128'h00000800080004004400020042001000;
//    yidaoqi[10] = 128'h00000800100002007f00020042001000;
//    yidaoqi[11] = 128'h00000800200042000400420042001000;
//    yidaoqi[12] = 128'h00000800420042000400440022001000;
//    yidaoqi[13] = 128'h00003e007e003c001f0038001c001000;
//    yidaoqi[14] = 128'h00000000000000000000000000000000;
//    yidaoqi[15] = 128'h00000000000000000000000000000000;
//end



    // ========== 初始化命令 ==========
    integer j;
    initial begin
        reg_init[0] = {1'b0, 8'h11};  // 退出睡眠
        reg_init[1] = {1'b0, 8'h3a};  // 像素格式
        reg_init[2] = {1'b1, 8'h05};  // 16位色
        reg_init[3] = {1'b0, 8'h36};  // 内存访问控制
        reg_init[4] = {1'b1, 8'h80};  // 设置
        reg_init[5] = {1'b0, 8'h29};  // 开启显示
        
        reg_setxy[0]  = {1'b0, 8'h2a};  // 列地址
        reg_setxy[1]  = {1'b1, 8'h00};
        reg_setxy[2]  = {1'b1, 8'h00};
        reg_setxy[3]  = {1'b1, 8'h00};
        reg_setxy[4]  = {1'b1, 8'd131};
        reg_setxy[5]  = {1'b0, 8'h2b};  // 行地址
        reg_setxy[6]  = {1'b1, 8'h00};
        reg_setxy[7]  = {1'b1, 8'h00};
        reg_setxy[8]  = {1'b1, 8'h00};
        reg_setxy[9]  = {1'b1, 8'd161};
        reg_setxy[10] = {1'b0, 8'h2c};  // 写内存
    end
    
    // ========== 状态机初始化 ==========
    initial begin
        state = IDLE;
        state_back = IDLE;
        x_cnt = 8'd0;
        y_cnt = 8'd0;
        cnt_write = 6'd0;
        cnt_delay = 24'd0;
        num_delay = 24'd0;
        cnt = 16'd0;
        cnt_main = 3'd0;
        cnt_init = 3'd0;
        cnt_scan = 4'd0;
        data_reg = 9'd0;
        high_word = 1'b1;
        clk_div = 2'd0;
        cs_r = 1'b1;
        dc_r = 1'b1;
        scl_r = 1'b1;
        sda_r = 1'b1;
        rst_r = 1'b0;
        show_pixel = 1'b0;
        pixel_color = COLOR_WHITE;
    end
    
    assign cs = cs_r;
    assign dc = dc_r;
    assign scl = scl_r;
    assign sda = sda_r;
    assign rst = rst_r;
    
    // ========== 时钟分频 ==========
    always @(posedge clk) begin
        clk_div <= clk_div + 1'b1;
    end
    
    // ========== 主状态机 ==========
    always @(posedge clk_spi) begin
        case(state)
            IDLE: begin
                x_cnt <= 8'd0;
                y_cnt <= 8'd0;
                cnt_main <= 3'd0;
                cnt_init <= 3'd0;
                cnt_scan <= 4'd0;
                high_word <= 1'b1;
                cnt <= 16'd0;
                cnt_write <= 6'd0;
                cnt_delay <= 24'd0;
                cs_r <= 1'b1;
                scl_r <= 1'b1;
                rst_r <= 1'b1;
                state <= MAIN;
                state_back <= MAIN;
            end
            
            MAIN: begin
                case(cnt_main)
                    3'd0: begin state <= INIT; cnt_main <= cnt_main + 1'b1; end
                    3'd1: begin state <= SCAN; cnt_main <= cnt_main + 1'b1; end
                    3'd2: begin cnt_main <= 3'd1; end
                    default: cnt_main <= 3'd0;
                endcase
            end
            
            INIT: begin
                case(cnt_init)
                    3'd0: begin
                        num_delay <= 24'd500000;
                        state <= DELAY;
                        state_back <= INIT;
                        cnt_init <= cnt_init + 1'b1;
                    end
                    3'd1: begin
                        if(cnt >= 6) begin
                            cnt <= 16'd0;
                            cnt_init <= cnt_init + 1'b1;
                        end else begin
                            data_reg <= reg_init[cnt];
                            num_delay <= 24'd5000;
                            cnt <= cnt + 1;
                            state <= WRITE;
                            state_back <= INIT;
                        end
                    end
                    3'd2: begin
                        cnt_init <= 3'd0;
                        state <= MAIN;
                    end
                    default: cnt_init <= 3'd0;
                endcase
            end
            
            SCAN: begin
                case(cnt_scan)
                    4'd0: begin
                        if(cnt >= 11) begin
                            cnt <= 16'd0;
                            cnt_scan <= cnt_scan + 1'b1;
                        end else begin
                            data_reg <= reg_setxy[cnt];
                            cnt <= cnt + 1;
                            num_delay <= 24'd1000;
                            state <= WRITE;
                            state_back <= SCAN;
                        end
                    end
                    
                    4'd1: begin
                        show_pixel = 1'b0;
                        pixel_color = COLOR_WHITE;
                        
                        // 演奏模式
                        if(y_cnt >= 5 && y_cnt <= 20 && x_cnt >= 34 && x_cnt <= 97) begin
                            if(yanzoumoshi[y_cnt-5][(x_cnt-34)]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_RED;
                            end
                        end
                        // 键组
                        else if(y_cnt >= 22 && y_cnt <= 37 && x_cnt >= 67 && x_cnt <= 130) begin
                            if(jianzu[y_cnt-22][(x_cnt-67)]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_BLUE;
                            end
                        end

                        // 显示当前音组 - 直接复用 A,B,C,D 的左边32列
                        else if(y_cnt >= 22 && y_cnt <= 37 && x_cnt >= 35 && x_cnt <= 66) begin
                            show_pixel = 1'b0;  // ← 关键：先清零
                            if(group_valid) begin
                                case(group)
                                    4'd2: if(A[y_cnt-22][(x_cnt-35)]) show_pixel = 1'b1;  // 复用"二"
                                    4'd3: if(B[y_cnt-22][(x_cnt-35)]) show_pixel = 1'b1;  // 复用"三"
                                    4'd4: if(C[y_cnt-22][(x_cnt-35)]) show_pixel = 1'b1;  // 复用"四"
                                    4'd5: if(D[y_cnt-22][(x_cnt-35)]) show_pixel = 1'b1;  // 复用"五"
                                endcase
                                if(show_pixel) pixel_color = COLOR_BLUE;
                            end
                        end
                        // 音量
                        else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 67 && x_cnt <= 130) begin
                            if(yingao[y_cnt-39][(x_cnt-67)]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_BLUE;
                            end
                        end
                        else if(y_cnt >= 73 && y_cnt <= 88 && x_cnt >= 0 && x_cnt <= 1) begin
                            if(Do[y_cnt-39][(x_cnt)]) begin
                                show_pixel = 0'b1;
                                pixel_color = COLOR_WHITE;
                            end
                        end
                        else if(y_cnt >= 73 && y_cnt <= 88 && x_cnt >= 2 && x_cnt <=3 ) begin
                            if(Re[y_cnt-39][(x_cnt-2)]) begin
                                show_pixel = 0'b1;
                                pixel_color = COLOR_WHITE;
                            end
                        end
                        else if(y_cnt >= 73 && y_cnt <= 88 && x_cnt >= 4 && x_cnt <= 5) begin
                            if(Mi[y_cnt-39][(x_cnt-4)]) begin
                                show_pixel = 0'b1;
                                pixel_color = COLOR_WHITE;
                            end
                        end
                        else if(y_cnt >= 105 && y_cnt <= 120 && x_cnt >= 6 && x_cnt <= 7) begin
                            if(Fa[y_cnt-39][(x_cnt-6)]) begin
                                show_pixel = 0'b1;
                                pixel_color = COLOR_WHITE;
                            end
                        end
                        else if(y_cnt >= 39 && y_cnt <= 40 && x_cnt >= 8 && x_cnt <= 9) begin
                            if(So[y_cnt-39][(x_cnt-8)]) begin
                                show_pixel = 0'b1;
                                pixel_color = COLOR_WHITE;
                            end
                        end                        
                        else if(y_cnt >= 39 && y_cnt <= 40 && x_cnt >= 10 && x_cnt <= 11) begin
                            if(La[y_cnt-39][(x_cnt-10)]) begin
                                show_pixel = 0'b1;
                                pixel_color = COLOR_WHITE;
                            end
                        end
                        else if(y_cnt >= 39 && y_cnt <= 40 && x_cnt >= 12 && x_cnt <= 13) begin
                            if(Si[y_cnt-39][(x_cnt-12)]) begin
                                show_pixel = 0'b1;
                                pixel_color = COLOR_WHITE;
                            end
                        end
                        // 显示当前按下的音符 (Y: 39-54, X: 35-66)
                        else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 35 && x_cnt <= 66) begin
                            show_pixel = 1'b0;  // ← 关键：先清零
                            if(note_valid && group_valid) begin
                                case(note)
                                    3'd1: if(Do[y_cnt-39][(x_cnt-35)]) show_pixel = 1'b1;
                                    3'd2: if(Re[y_cnt-39][(x_cnt-35)]) show_pixel = 1'b1;
                                    3'd3: if(Mi[y_cnt-39][(x_cnt-35)]) show_pixel = 1'b1;
                                    3'd4: if(Fa[y_cnt-39][(x_cnt-35)]) show_pixel = 1'b1;
                                    3'd5: if(So[y_cnt-39][(x_cnt-35)]) show_pixel = 1'b1;
                                    3'd6: if(La[y_cnt-39][(x_cnt-35)]) show_pixel = 1'b1;
                                    3'd7: if(Si[y_cnt-39][(x_cnt-35)]) show_pixel = 1'b1;
                                endcase
                                if(show_pixel) pixel_color = COLOR_RED;  // 用红色突出显示
                            end
                        end
                        // ========== 音量区域 (Y: 56-71) ==========
//                        else if(y_cnt >= 56 && y_cnt <= 71 && x_cnt >= 67 && x_cnt <= 130) begin
//                            if(yinliang[y_cnt-56][(x_cnt-67)]) begin
//                                show_pixel = 1'b1;
//                                pixel_color = COLOR_BLUE;
//                            end
//                        end
                        // A
                        else if(y_cnt >= 73 && y_cnt <= 88 && x_cnt >= 67 && x_cnt <= 130) begin
                            if(A[y_cnt-73][(x_cnt-67)]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_BLACK;
                            end
                        end
                        // B
                        else if(y_cnt >= 90 && y_cnt <= 105 && x_cnt >= 67 && x_cnt <= 130) begin
                            if(B[y_cnt-90][(x_cnt-67)]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_BLACK;
                            end
                        end
                        // C
                        else if(y_cnt >= 107 && y_cnt <= 122 && x_cnt >= 67 && x_cnt <= 130) begin
                            if(C[y_cnt-107][(x_cnt-67)]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_BLACK;
                            end
                        end
                        // D
                        else if(y_cnt >= 124 && y_cnt <= 139 && x_cnt >= 67 && x_cnt <= 130) begin
                            if(D[y_cnt-124][(x_cnt-67)]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_BLACK;
                            end
                        end
                        // F
                        else if(y_cnt >= 141 && y_cnt <= 156 && x_cnt >= 67 && x_cnt <= 130) begin
                            if(F[y_cnt-141][(x_cnt-67)]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_RED;
                            end
                        end
                        
                        if(show_pixel) begin
                            data_reg <= {1'b1, pixel_color[15:8]};
                        end else begin
                            data_reg <= {1'b1, COLOR_WHITE[15:8]};
                        end
                        
                        num_delay <= 24'd100;
                        state <= WRITE;
                        state_back <= SCAN;
                        cnt_scan <= cnt_scan + 1'b1;
                    end
                    
                    4'd2: begin
                        if(high_word) begin
                            if(show_pixel) begin
                                data_reg <= {1'b1, pixel_color[7:0]};
                            end else begin
                                data_reg <= {1'b1, COLOR_WHITE[7:0]};
                            end
                            num_delay <= 24'd100;
                            state <= WRITE;
                            state_back <= SCAN;
                            high_word <= 1'b0;
                        end else begin
                            high_word <= 1'b1;
                            if(x_cnt >= LCD_W-1) begin
                                x_cnt <= 8'd0;
                                if(y_cnt >= LCD_H-1) begin
                                    y_cnt <= 8'd0;
                                    cnt_scan <= 4'd0;
                                end else begin
                                    y_cnt <= y_cnt + 1'b1;
                                    cnt_scan <= 4'd1;
                                end
                            end else begin
                                x_cnt <= x_cnt + 1'b1;
                                cnt_scan <= 4'd1;
                            end
                        end
                    end
                    
                    default: cnt_scan <= 4'd0;
                endcase
            end
            
            WRITE: begin
                if(cnt_write >= 6'd17) begin
                    cnt_write <= 6'd0;
                    state <= DELAY;
                end else begin
                    cnt_write <= cnt_write + 1'b1;
                end
                cs_r <= 1'b0;
                case(cnt_write)
                    6'd0:  dc_r <= data_reg[8];
                    6'd1:  begin scl_r <= LOW; sda_r <= data_reg[7]; end
                    6'd2:  scl_r <= HIGH;
                    6'd3:  begin scl_r <= LOW; sda_r <= data_reg[6]; end
                    6'd4:  scl_r <= HIGH;
                    6'd5:  begin scl_r <= LOW; sda_r <= data_reg[5]; end
                    6'd6:  scl_r <= HIGH;
                    6'd7:  begin scl_r <= LOW; sda_r <= data_reg[4]; end
                    6'd8:  scl_r <= HIGH;
                    6'd9:  begin scl_r <= LOW; sda_r <= data_reg[3]; end
                    6'd10: scl_r <= HIGH;
                    6'd11: begin scl_r <= LOW; sda_r <= data_reg[2]; end
                    6'd12: scl_r <= HIGH;
                    6'd13: begin scl_r <= LOW; sda_r <= data_reg[1]; end
                    6'd14: scl_r <= HIGH;
                    6'd15: begin scl_r <= LOW; sda_r <= data_reg[0]; end
                    6'd16: scl_r <= HIGH;
                    6'd17: scl_r <= LOW;
                    default: begin end
                endcase
            end
            
            DELAY: begin
                cs_r <= 1'b1;
                if(cnt_delay >= num_delay) begin
                    cnt_delay <= 24'd0;
                    state <= state_back;
                end else begin
                    cnt_delay <= cnt_delay + 1'b1;
                end
            end
            
            default: state <= IDLE;
        endcase
    end

endmodule