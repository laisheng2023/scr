module bofangmoshi(
    input  clk_27m,
    output cs,
    output dc,
    output scl,
    output sda,
    output rst,
    input [1:0] music_select,
    input play_pause,
    input [2:0] volume
);

// ========== 参数 ==========
localparam LCD_W = 8'd132;
localparam LCD_H = 8'd162;

localparam COLOR_RED   = 16'hF800;
localparam COLOR_WHITE = 16'hFFFF;
localparam COLOR_BLUE  = 16'h001F;
localparam COLOR_GREEN = 16'h07E0;
localparam BG_D_BG       = 16'h0010;  // 背景：深藏青
localparam BG_D_TEXT     = 16'hC618;  // 字体：浅灰白（不刺眼）


localparam IDLE  = 4'd0;
localparam MAIN  = 4'd1;
localparam INIT  = 4'd2;
localparam SCAN  = 4'd3;
localparam WRITE = 4'd4;
localparam DELAY = 4'd5;

localparam LOW  = 1'b0;
localparam HIGH = 1'b1;

// ========== 寄存器 ==========
reg [3:0] state;
reg [3:0] state_back;

reg [7:0] x_cnt;
reg [7:0] y_cnt;
reg [5:0] cnt_write;
reg [23:0] cnt_delay;
reg [23:0] num_delay;
reg [15:0] cnt;
reg [2:0] cnt_main;
reg [2:0] cnt_init;
reg [3:0] cnt_scan;
reg [8:0] data_reg;
reg high_word;
reg [1:0] clk_div;

reg cs_r;
reg dc_r;
reg scl_r;
reg sda_r;
reg rst_r;

reg show_pixel;
reg [15:0] pixel_color;

wire clk_spi;
assign clk_spi = clk_div[0];

// ========== 点阵存储 (16行 x 32列) ==========

   
// ========== 初始化命令 ==========
reg [8:0] reg_init [0:5];
reg [8:0] reg_setxy [0:10];


// ========== 点阵数据 ==========
// ========== 点阵存储 (132行 x 80列 = 10字节/行) ==========
reg [0:63] bofangmoshi [0:15];
reg [0:63] zhuangtai [0:15];
reg [0:127] kongzhi [0:15];
reg [0:63] yinliang [0:15];
reg [0:127] yljj [0:15];
reg [0:127] fanhui [0:15];
reg [63:0] xiaoxx [0:15];
reg [63:0] qingtian [0:15];
reg [63:0] laohu [0:15];
reg [63:0] jinglebells [0:15];  // 新增：铃儿响叮当歌名字形
reg [63:0] gequ [0:15];
reg [63:0] xiangdd [0:15];

reg [0:15] er [0:15];      // 2
reg [0:15] san [0:15];     // 3
reg [0:15] si [0:15];      // 4
reg [0:15] ling [0:15];      // 0
reg [0:15] yi [0:15];      // 1
initial begin
    xiangdd[0]  = 64'h0040000001000000;
    xiangdd[1]  = 64'h0040000021080000;
    xiangdd[2]  = 64'h78807bfe11080000;
    xiangdd[3]  = 64'h4bfc482009100000;
    xiangdd[4]  = 64'h4a04482009200000;
    xiangdd[5]  = 64'h4a04482001000000;
    xiangdd[6]  = 64'h4af448207ff80000;
    xiangdd[7]  = 64'h4a94482000080000;
    xiangdd[8]  = 64'h4a94482000080000;
    xiangdd[9]  = 64'h4a94482000080000;
    xiangdd[10] = 64'h7a9478203ff80000;
    xiangdd[11] = 64'h4af4482000080000;
    xiangdd[12] = 64'h0204002000080000;
    xiangdd[13] = 64'h0204002000080000;
    xiangdd[14] = 64'h021400a07ff80000;
    xiangdd[15] = 64'h0208004000080000;
end

// ========== 点阵数据 ==========
// ========== 点阵播放模式数据 (16行 x 64列) ==========
initial begin
    bofangmoshi[0]  = 64'h2078204011100048;
    bofangmoshi[1]  = 64'h27c0104011100044;
    bofangmoshi[2]  = 64'h2248004017fc0044;
    bofangmoshi[3]  = 64'h2150fe8011100040;
    bofangmoshi[4]  = 64'hfbfc20fefc00fffe;
    bofangmoshi[5]  = 64'h2150210813f80040;
    bofangmoshi[6]  = 64'h22483e8832080040;
    bofangmoshi[7]  = 64'h2c0624883bf83e40;
    bofangmoshi[8]  = 64'h33f8248856080840;
    bofangmoshi[9]  = 64'he248245053f80840;
    bofangmoshi[10] = 64'h2248245090400820;
    bofangmoshi[11] = 64'h23f8242017fc0822;
    bofangmoshi[12] = 64'h2248445010a00f12;
    bofangmoshi[13] = 64'h224854881110780a;
    bofangmoshi[14] = 64'ha3f8890412082006;
    bofangmoshi[15] = 64'h4208020214060002;
end
// ========== 点阵状态数据 (16行 x 64列) ==========
initial begin
    zhuangtai[0]  = 64'h0840010000000000;
    zhuangtai[1]  = 64'h0848010000000000;
    zhuangtai[2]  = 64'h08447ffc00000000;
    zhuangtai[3]  = 64'h4844010000000000;
    zhuangtai[4]  = 64'h2840028000000000;
    zhuangtai[5]  = 64'h2ffe044000000000;
    zhuangtai[6]  = 64'h08400a2000000000;
    zhuangtai[7]  = 64'h0840311800000000;
    zhuangtai[8]  = 64'h1840c00600000000;
    zhuangtai[9]  = 64'h28a0010030000000;
    zhuangtai[10] = 64'hc8a0088830000000;
    zhuangtai[11] = 64'h0890488400000000;
    zhuangtai[12] = 64'h0910481230000000;
    zhuangtai[13] = 64'h0908481230000000;
    zhuangtai[14] = 64'h0a0487f000000000;
    zhuangtai[15] = 64'h0c02000000000000;
end
// ========== 点阵音量数据 (16行 x 64列) ==========
initial begin
    yinliang[0]  = 64'h0200000000000000;
    yinliang[1]  = 64'h01001ff000000000;
    yinliang[2]  = 64'h3ff8101000000000;
    yinliang[3]  = 64'h00001ff000000000;
    yinliang[4]  = 64'h0820101000000000;
    yinliang[5]  = 64'h0440fffe00000000;
    yinliang[6]  = 64'hfffe000000000000;
    yinliang[7]  = 64'h00001ff000000000;
    yinliang[8]  = 64'h1ff0111000000000;
    yinliang[9]  = 64'h10101ff030000000;
    yinliang[10] = 64'h1010111030000000;
    yinliang[11] = 64'h1ff01ff000000000;
    yinliang[12] = 64'h1010010030000000;
    yinliang[13] = 64'h10101ff030000000;
    yinliang[14] = 64'h1ff0010000000000;
    yinliang[15] = 64'h10107ffc00000000;
end
// ========== 点阵控制数据 (16行 x 128列) ==========
initial begin
    kongzhi[0]  = 128'h00002078204000000000100c10800000;
    kongzhi[1]  = 128'h000027c0104000000000fef010400000;
    kongzhi[2]  = 128'h00002248004000000000208017fc0000;
    kongzhi[3]  = 128'h10002150fe800000f800488020000000;
    kongzhi[4]  = 128'h1000fbfc20fe000044007efe23f80000;
    kongzhi[5]  = 128'h18002150210800004400088862080000;
    kongzhi[6]  = 128'h280022483e88000044000e8863f80000;
    kongzhi[7]  = 128'h28002c06248800007800f908a0000000;
    kongzhi[8]  = 128'h240033f82488000044004a082ffe0000;
    kongzhi[9]  = 128'h3c00e2482450000042001ff828020000;
    kongzhi[10] = 128'h44002248245000004200101023f80000;
    kongzhi[11] = 128'h420023f8242000004200101020400000;
    kongzhi[12] = 128'h420022484450000044001ff020400000;
    kongzhi[13] = 128'he700224854880000f800101020400000;
    kongzhi[14] = 128'h0000a3f8890400000000101021400000;
    kongzhi[15] = 128'h000042080202000000001ff020800000;
end

// ========== 点阵音量加减数据 (16行 x 128列) ==========
initial begin
    yljj[0]  = 128'h00000200000000000000020000000000;
    yljj[1]  = 128'h00000100000000000000010000000000;
    yljj[2]  = 128'h00003ff80000000000003ff800000000;
    yljj[3]  = 128'h3c000000000000003800000000000000;
    yljj[4]  = 128'h42000820000000004400082000000000;
    yljj[5]  = 128'h42000440080000004200044000000000;
    yljj[6]  = 128'h4200fffe080000004200fffe00000000;
    yljj[7]  = 128'h24000000080000004200000000000000;
    yljj[8]  = 128'h18001ff07f00000046001ff07e000000;
    yljj[9]  = 128'h24001010080000003a00101000000000;
    yljj[10] = 128'h42001010080000000200101000000000;
    yljj[11] = 128'h42001ff00800000002001ff000000000;
    yljj[12] = 128'h42001010000000002400101000000000;
    yljj[13] = 128'h3c001010000000001800101000000000;
    yljj[14] = 128'h00001ff00000000000001ff000000000;
    yljj[15] = 128'h00001010000000000000101000000000;
end

// ========== 点阵返回数据 (16行 x 128列) ==========
initial begin
    fanhui[0]  = 128'h00000008000000000000100000200000;
    fanhui[1]  = 128'h0000203c3ff8000000001000ff200000;
    fanhui[2]  = 128'h000013c020080000000011fc02200000;
    fanhui[3]  = 128'hfc00120020080000fc0010447a7e0000;
    fanhui[4]  = 128'h4200020027c80000420010444a420000;
    fanhui[5]  = 128'h480003fc2448000048001e447a840000;
    fanhui[6]  = 128'h4800f204244800004800f04400100000;
    fanhui[7]  = 128'h780012882448000078001044ff100000;
    fanhui[8]  = 128'h48001250244800004800104402100000;
    fanhui[9]  = 128'h4800122024480000480012447a100000;
    fanhui[10] = 128'h4000125027c80000400014444a280000;
    fanhui[11] = 128'h4000148820080000420018844a280000;
    fanhui[12] = 128'h4000150420080000420010847a280000;
    fanhui[13] = 128'he00028003ff80000fc00010402440000;
    fanhui[14] = 128'h000047fe20080000000002280a440000;
    fanhui[15] = 128'h00000000000000000000041004820000;
end

initial begin
    xiaoxx[0]  = 64'h0100000000000000;
    xiaoxx[1]  = 64'h01001ff01ff00000;
    xiaoxx[2]  = 64'h0100101010100000;
    xiaoxx[3]  = 64'h01001ff01ff00000;
    xiaoxx[4]  = 64'h0100101010100000;
    xiaoxx[5]  = 64'h11101ff01ff00000;
    xiaoxx[6]  = 64'h1108010001000000;
    xiaoxx[7]  = 64'h1104110011000000;
    xiaoxx[8]  = 64'h21041ff81ff80000;
    xiaoxx[9]  = 64'h2102210021000000;
    xiaoxx[10] = 64'h4102410041000000;
    xiaoxx[11] = 64'h81021ff01ff00000;
    xiaoxx[12] = 64'h0100010001000000;
    xiaoxx[13] = 64'h0100010001000000;
    xiaoxx[14] = 64'h05007ffc7ffc0000;
    xiaoxx[15] = 64'h0200000000000000;
end

initial begin
    qingtian[0]  = 64'h0020000000000000;
    qingtian[1]  = 64'h00203ff800000000;
    qingtian[2]  = 64'h7bfe010000000000;
    qingtian[3]  = 64'h4820010000000000;
    qingtian[4]  = 64'h49fc010000000000;
    qingtian[5]  = 64'h4820010000000000;
    qingtian[6]  = 64'h4bfefffe00000000;
    qingtian[7]  = 64'h7800010000000000;
    qingtian[8]  = 64'h49fc028000000000;
    qingtian[9]  = 64'h4904028000000000;
    qingtian[10] = 64'h49fc044000000000;
    qingtian[11] = 64'h4904044000000000;
    qingtian[12] = 64'h79fc082000000000;
    qingtian[13] = 64'h4904101000000000;
    qingtian[14] = 64'h0114200800000000;
    qingtian[15] = 64'h0108c00600000000;
end

initial begin
    laohu[0]  = 64'h0000000002000100;
    laohu[1]  = 64'hfffe1ff0020801f8;
    laohu[2]  = 64'h044010103fd00100;
    laohu[3]  = 64'h0440101002203ffc;
    laohu[4]  = 64'h0440101002402104;
    laohu[5]  = 64'h7ffc1010fffe2160;
    laohu[6]  = 64'h4444101001002f88;
    laohu[7]  = 64'h4444101002002108;
    laohu[8]  = 64'h44441ff00c1020f8;
    laohu[9]  = 64'h4aa4101018e02000;
    laohu[10] = 64'h4a9400002f0023e0;
    laohu[11] = 64'h5114082048082220;
    laohu[12] = 64'h4204081088082220;
    laohu[13] = 64'h4004100808084424;
    laohu[14] = 64'h4014200407f84824;
    laohu[15] = 64'h400840040000901c;
end

// ========== 铃儿响叮当歌名字形 (16行 x 64列) ==========
// "JINGLE BELLS" 的点阵字形
initial begin
    jinglebells[0]  = 64'h0000000000000000;
    jinglebells[1]  = 64'h0000000000000000;
    jinglebells[2]  = 64'h0000000000000000;
    jinglebells[3]  = 64'h0000000000000000;
    jinglebells[4]  = 64'h0000000000000000;
    jinglebells[5]  = 64'h0000000000000000;
    jinglebells[6]  = 64'h0000000000000000;
    jinglebells[7]  = 64'h0000000000000000;
    jinglebells[8]  = 64'h0000000000000000;
    jinglebells[9]  = 64'h0000000000000000;
    jinglebells[10] = 64'h0000000000000000;
    jinglebells[11] = 64'h0000000000000000;
    jinglebells[12] = 64'h0000000000000000;
    jinglebells[13] = 64'h0000000000000000;
    jinglebells[14] = 64'h0000000000000000;
    jinglebells[15] = 64'h0000000000000000;
end

initial begin
    gequ[0]  = 64'h0020044000000000;
    gequ[1]  = 64'hff20044000000000;
    gequ[2]  = 64'h0220044000000000;
    gequ[3]  = 64'h7a7e044000000000;
    gequ[4]  = 64'h4a427ffc00000000;
    gequ[5]  = 64'h7a84444400000000;
    gequ[6]  = 64'h0010444400000000;
    gequ[7]  = 64'hff10444400000000;
    gequ[8]  = 64'h0210444400000000;
    gequ[9]  = 64'h7a107ffc30000000;
    gequ[10] = 64'h4a28444430000000;
    gequ[11] = 64'h4a28444400000000;
    gequ[12] = 64'h7a28444430000000;
    gequ[13] = 64'h0244444430000000;
    gequ[14] = 64'h0a447ffc00000000;
    gequ[15] = 64'h0482400400000000;
end
initial begin
    ling[0]  = 16'h0000;
    ling[1]  = 16'h0000;
    ling[2]  = 16'h0000;
    ling[3]  = 16'h1800;
    ling[4]  = 16'h2400;
    ling[5]  = 16'h4200;
    ling[6]  = 16'h4200;
    ling[7]  = 16'h4200;
    ling[8]  = 16'h4200;
    ling[9]  = 16'h4200;
    ling[10] = 16'h4200;
    ling[11] = 16'h4200;
    ling[12] = 16'h2400;
    ling[13] = 16'h1800;
    ling[14] = 16'h0000;
    ling[15] = 16'h0000;
end
initial begin
    yi[0]  = 16'h0000;
    yi[1]  = 16'h0000;
    yi[2]  = 16'h0000;
    yi[3]  = 16'h0800;
    yi[4]  = 16'h3800;
    yi[5]  = 16'h0800;
    yi[6]  = 16'h0800;
    yi[7]  = 16'h0800;
    yi[8]  = 16'h0800;
    yi[9]  = 16'h0800;
    yi[10] = 16'h0800;
    yi[11] = 16'h0800;
    yi[12] = 16'h0800;
    yi[13] = 16'h3e00;
    yi[14] = 16'h0000;
    yi[15] = 16'h0000;
end

// ========== 点阵2数据 (16行 x 16列) 原始 ==========
initial begin
    er[0]  = 16'h0000;
    er[1]  = 16'h0000;
    er[2]  = 16'h0000;
    er[3]  = 16'h3c00;
    er[4]  = 16'h4200;
    er[5]  = 16'h4200;
    er[6]  = 16'h0200;
    er[7]  = 16'h0400;
    er[8]  = 16'h0800;
    er[9]  = 16'h1000;
    er[10] = 16'h2000;
    er[11] = 16'h4200;
    er[12] = 16'h7e00;
    er[13] = 16'h0000;
    er[14] = 16'h0000;
    er[15] = 16'h0000;
end

// ========== 点阵3数据 (16行 x 16列) 原始 ==========
initial begin
    san[0]  = 16'h0000;
    san[1]  = 16'h0000;
    san[2]  = 16'h0000;
    san[3]  = 16'h3c00;
    san[4]  = 16'h4200;
    san[5]  = 16'h4200;
    san[6]  = 16'h0200;
    san[7]  = 16'h0400;
    san[8]  = 16'h1800;
    san[9]  = 16'h0400;
    san[10] = 16'h0200;
    san[11] = 16'h4200;
    san[12] = 16'h4200;
    san[13] = 16'h3c00;
    san[14] = 16'h0000;
    san[15] = 16'h0000;
end

// ========== 点阵4数据 (16行 x 16列) 原始 ==========
initial begin
    si[0]  = 16'h0000;
    si[1]  = 16'h0000;
    si[2]  = 16'h0000;
    si[3]  = 16'h0400;
    si[4]  = 16'h0c00;
    si[5]  = 16'h0c00;
    si[6]  = 16'h1400;
    si[7]  = 16'h2400;
    si[8]  = 16'h2400;
    si[9]  = 16'h4400;
    si[10] = 16'h7f00;
    si[11] = 16'h0400;
    si[12] = 16'h0400;
    si[13] = 16'h1f00;
    si[14] = 16'h0000;
    si[15] = 16'h0000;
end




// ========== 初始化命令 ==========
integer j;
initial begin
    // 初始化命令
    reg_init[0] = {1'b0, 8'h11};  // 退出睡眠
    reg_init[1] = {1'b0, 8'h3a};  // 像素格式
    reg_init[2] = {1'b1, 8'h05};  // 16位色
    reg_init[3] = {1'b0, 8'h36};  // 内存访问控制
    reg_init[4] = {1'b1, 8'h80};  // 设置
    reg_init[5] = {1'b0, 8'h29};  // 开启显示
    
    // 显示区域
    reg_setxy[0]  = {1'b0, 8'h2a};  // 列地址
    reg_setxy[1]  = {1'b1, 8'h00};
    reg_setxy[2]  = {1'b1, 8'h00};
    reg_setxy[3]  = {1'b1, 8'h00};
    reg_setxy[4]  = {1'b1, 8'd131};
    reg_setxy[5]  = {1'b0, 8'h2b};  // 行地址
    reg_setxy[6]  = {1'b1, 8'h00};
    reg_setxy[7]  = {1'b1, 8'h00};
    reg_setxy[8]  = {1'b1, 8'h00};
    reg_setxy[9]  = {1'b1, 8'd161};
    reg_setxy[10] = {1'b0, 8'h2c};  // 写内存
end

// 状态机初始值
initial begin
    state = IDLE;
    state_back = IDLE;
    x_cnt = 8'd0;
    y_cnt = 8'd0;
    cnt_write = 6'd0;
    cnt_delay = 24'd0;
    num_delay = 24'd0;
    cnt = 16'd0;
    cnt_main = 3'd0;
    cnt_init = 3'd0;
    cnt_scan = 4'd0;
    data_reg = 9'd0;
    high_word = 1'b1;
    clk_div = 2'd0;
    cs_r = 1'b1;
    dc_r = 1'b1;
    scl_r = 1'b1;
    sda_r = 1'b1;
    rst_r = 1'b0;
    show_pixel = 1'b0;
end

assign cs = cs_r;
assign dc = dc_r;
assign scl = scl_r;
assign sda = sda_r;
assign rst = rst_r;

// ========== 时钟分频 ==========
always @(posedge clk_27m) begin
    clk_div <= clk_div + 1'b1;
end

// ========== 主状态机 ==========
always @(posedge clk_spi) begin
    case(state)
        IDLE: begin
            x_cnt <= 8'd0;
            y_cnt <= 8'd0;
            cnt_main <= 3'd0;
            cnt_init <= 3'd0;
            cnt_scan <= 4'd0;
            high_word <= 1'b1;
            cnt <= 16'd0;
            cnt_write <= 6'd0;
            cnt_delay <= 24'd0;
            cs_r <= 1'b1;
            scl_r <= 1'b1;
            rst_r <= 1'b1;
            state <= MAIN;
            state_back <= MAIN;
        end
        
        MAIN: begin
            case(cnt_main)
                3'd0: begin state <= INIT; cnt_main <= cnt_main + 1'b1; end
                3'd1: begin state <= SCAN; cnt_main <= cnt_main + 1'b1; end
                3'd2: begin cnt_main <= 3'd1; end
                default: cnt_main <= 3'd0;
            endcase
        end
        
        INIT: begin
            case(cnt_init)
                3'd0: begin
                    num_delay <= 24'd500000;
                    state <= DELAY;
                    state_back <= INIT;
                    cnt_init <= cnt_init + 1'b1;
                end
                3'd1: begin
                    if(cnt >= 6) begin
                        cnt <= 16'd0;
                        cnt_init <= cnt_init + 1'b1;
                    end else begin
                        data_reg <= reg_init[cnt];
                        num_delay <= 24'd5000;
                        cnt <= cnt + 1;
                        state <= WRITE;
                        state_back <= INIT;
                    end
                end
                3'd2: begin
                    cnt_init <= 3'd0;
                    state <= MAIN;
                end
                default: cnt_init <= 3'd0;
            endcase
        end
        
        SCAN: begin
            case(cnt_scan)
                4'd0: begin
                    if(cnt >= 11) begin
                        cnt <= 16'd0;
                        cnt_scan <= cnt_scan + 1'b1;
                    end else begin
                        data_reg <= reg_setxy[cnt];
                        cnt <= cnt + 1;
                        num_delay <= 24'd1000;
                        state <= WRITE;
                        state_back <= SCAN;
                    end
                end
                
                // ========== 点阵显示 - 顶部居中 ==========
                4'd1: begin
                    show_pixel = 1'b0;
                    // Y范围: 10-25 (16行), X范围: 50-81 (32列)
                    if(y_cnt >= 5 && y_cnt <= 20 && x_cnt >= 34 && x_cnt <= 97) begin
                        if(bofangmoshi[y_cnt-5][ (x_cnt-34)]) show_pixel = 1'b1;
                    end
                    
                    else if(y_cnt >= 22 && y_cnt <= 37 && x_cnt >= 67 && x_cnt <= 130) begin
                        if(zhuangtai[y_cnt-22][ (x_cnt-67)]) show_pixel = 1'b1;
                    end

                    else if(y_cnt >= 22 && y_cnt <= 37 && x_cnt >= 35 && x_cnt <= 66) begin
                        show_pixel = 1'b0;
                            if(play_pause == 1'b0) begin  // 播放状态
                                if(kongzhi[y_cnt-22][ (x_cnt-35)+15]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_RED;
                            end
                        end else begin  // 暂停状态
                            if(kongzhi[y_cnt-22][ (x_cnt-35)+79]) begin
                                show_pixel = 1'b1;
                                pixel_color = COLOR_RED;
                            end
                        end
                    end

                    else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 67 && x_cnt <= 130) begin
                        if(yinliang[y_cnt-39][ (x_cnt-67)]) show_pixel = 1'b1;
                    end

                     // ========== 音量数字显示 (Y: 56-71, X: 35-66) ==========
                        else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 51 && x_cnt <= 66) begin
                            show_pixel = 1'b0;
                            case(volume)
                                3'd0: if(ling[y_cnt-39][(x_cnt-51)]) begin show_pixel = 1'b1; pixel_color = COLOR_RED; end
                                3'd1: if(yi[y_cnt-39][(x_cnt-51)])   begin show_pixel = 1'b1; pixel_color = COLOR_RED; end
                                3'd2: if(er[y_cnt-39][(x_cnt-51)])   begin show_pixel = 1'b1; pixel_color = COLOR_RED; end
                                3'd3: if(san[y_cnt-39][(x_cnt-51)])  begin show_pixel = 1'b1; pixel_color = COLOR_RED; end
                                3'd4: if(si[y_cnt-39][(x_cnt-51)])   begin show_pixel = 1'b1; pixel_color = COLOR_RED; end
                                default: show_pixel = 1'b0;
                            endcase
                        end
                    else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 0 && x_cnt <= 1) begin
                        if(ling[y_cnt-39][ (x_cnt)]) show_pixel = 1'b1;
                    end
                    else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 2 && x_cnt <= 3) begin
                        if(yi[y_cnt-39][ (x_cnt-2)]) show_pixel = 1'b1;
                    end
                    else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 4 && x_cnt <= 5) begin
                        if(er[y_cnt-39][ (x_cnt-4)]) show_pixel = 1'b1;
                    end
                    else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 6 && x_cnt <= 7) begin
                        if(san[y_cnt-39][ (x_cnt-6)]) show_pixel = 1'b1;
                    end
                    else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 8 && x_cnt <= 9) begin
                        if(si[y_cnt-39][ (x_cnt-8)]) show_pixel = 1'b1;
                    end
                    // 歌名显示区域: Y: 56-71, X: 67-130
                    else if(y_cnt >= 56 && y_cnt <= 71 && x_cnt >= 67 && x_cnt <= 130) begin
                        if(gequ[y_cnt-56][ (x_cnt-67)]) show_pixel = 1'b1;
                    end
                    
                    // ========== 歌名显示区域 (Y: 56-71, X: 3-66) ==========
                    else if(y_cnt >= 56 && y_cnt <= 71 && x_cnt >= 3 && x_cnt <= 66) begin
                        show_pixel = 1'b0;
                        case(music_select)
                            2'b01: begin  // 晴天
                                if(qingtian[y_cnt-56][ (x_cnt-3)]) begin
                                    show_pixel = 1'b1;
                                    pixel_color = COLOR_RED;
                                end
                            end
                            2'b10: begin  // 小星星
                                if(xiaoxx[y_cnt-56][ (x_cnt-3)]) begin
                                    show_pixel = 1'b1;
                                    pixel_color = COLOR_RED;
                                end
                            end
                            2'b11: begin  // 两只老虎
                                if(laohu[y_cnt-56][ (x_cnt-3)]) begin
                                    show_pixel = 1'b1;
                                    pixel_color = COLOR_RED;
                                end
                            end
                            2'b00: begin  // 铃儿响叮当
                                if(xiangdd[y_cnt-56][ (x_cnt-3)]) begin
                                    show_pixel = 1'b1;
                                    pixel_color = COLOR_RED;
                                end
                            end
                            default: begin
                                show_pixel = 1'b0;
                                pixel_color = COLOR_WHITE;
                            end
                        endcase
                    end
                    
                    // 歌曲选择图标区域 (Y: 77-92, X: 0-5)
                    else if(y_cnt >= 77 && y_cnt <= 92 && x_cnt >= 0 && x_cnt <= 1) begin
                        if(qingtian[y_cnt-77][ (x_cnt)]) show_pixel = 1'b1;
                    end
                    else if(y_cnt >= 77 && y_cnt <= 92 && x_cnt >= 2 && x_cnt <= 3) begin
                        if(xiaoxx[y_cnt-77][ (x_cnt-2)]) show_pixel = 1'b1;
                    end
                    else if(y_cnt >= 77 && y_cnt <= 92 && x_cnt >= 4 && x_cnt <= 5) begin
                        if(laohu[y_cnt-77][ (x_cnt-4)]) show_pixel = 1'b1;
                    end
                    // 新增铃儿响叮当选择图标 (Y: 77-92, X: 6-7)
                    else if(y_cnt >= 77 && y_cnt <= 92 && x_cnt >= 6 && x_cnt <= 7) begin
                        if(xiangdd[y_cnt-77][ (x_cnt-6)]) show_pixel = 1'b1;
                    end
            
                    else if(y_cnt >= 107 && y_cnt <= 122 && x_cnt >= 2 && x_cnt <= 129) begin
                        if(kongzhi[y_cnt-107][ (x_cnt-2)]) show_pixel = 1'b1;
                    end

                    else if(y_cnt >= 124 && y_cnt <= 139 && x_cnt >= 2 && x_cnt <= 129) begin
                        if(yljj[y_cnt-124][ (x_cnt-2)]) show_pixel = 1'b1;
                    end

                    else if(y_cnt >= 141 && y_cnt <= 156 && x_cnt >= 2 && x_cnt <= 129) begin
                        if(fanhui[y_cnt-141][ (x_cnt-2)]) show_pixel = 1'b1;
                    end
                    
                    if(show_pixel) begin
                        data_reg <= {1'b1, COLOR_RED[15:8]};
                    end else begin
                        data_reg <= {1'b1, COLOR_WHITE[15:8]};
                    end
                    num_delay <= 24'd100;
                    state <= WRITE;
                    state_back <= SCAN;
                    cnt_scan <= cnt_scan + 1'b1;
                end
                
                4'd2: begin  // 点阵低字节
                    if(high_word) begin
                        if(show_pixel) begin
                            data_reg <= {1'b1, COLOR_RED[7:0]};
                        end else begin
                            data_reg <= {1'b1, COLOR_WHITE[7:0]};
                        end
                        num_delay <= 24'd100;
                        state <= WRITE;
                        state_back <= SCAN;
                        high_word <= 1'b0;
                    end else begin
                        high_word <= 1'b1;
                        if(x_cnt >= LCD_W-1) begin
                            x_cnt <= 8'd0;
                            if(y_cnt >= LCD_H-1) begin
                                y_cnt <= 8'd0;
                                cnt_scan <= 4'd0;
                            end else begin
                                y_cnt <= y_cnt + 1'b1;
                                cnt_scan <= 4'd1;
                            end
                        end else begin
                            x_cnt <= x_cnt + 1'b1;
                            cnt_scan <= 4'd1;
                        end
                    end
                end
                
                default: cnt_scan <= 4'd0;
            endcase
        end
        
        WRITE: begin
            if(cnt_write >= 6'd17) begin
                cnt_write <= 6'd0;
                state <= DELAY;
            end else begin
                cnt_write <= cnt_write + 1'b1;
            end
            cs_r <= 1'b0;
            case(cnt_write)
                6'd0:  dc_r <= data_reg[8];
                6'd1:  begin scl_r <= LOW; sda_r <= data_reg[7]; end
                6'd2:  scl_r <= HIGH;
                6'd3:  begin scl_r <= LOW; sda_r <= data_reg[6]; end
                6'd4:  scl_r <= HIGH;
                6'd5:  begin scl_r <= LOW; sda_r <= data_reg[5]; end
                6'd6:  scl_r <= HIGH;
                6'd7:  begin scl_r <= LOW; sda_r <= data_reg[4]; end
                6'd8:  scl_r <= HIGH;
                6'd9:  begin scl_r <= LOW; sda_r <= data_reg[3]; end
                6'd10: scl_r <= HIGH;
                6'd11: begin scl_r <= LOW; sda_r <= data_reg[2]; end
                6'd12: scl_r <= HIGH;
                6'd13: begin scl_r <= LOW; sda_r <= data_reg[1]; end
                6'd14: scl_r <= HIGH;
                6'd15: begin scl_r <= LOW; sda_r <= data_reg[0]; end
                6'd16: scl_r <= HIGH;
                6'd17: scl_r <= LOW;
                default: begin end
            endcase
        end
        
        DELAY: begin
            cs_r <= 1'b1;
            if(cnt_delay >= num_delay) begin
                cnt_delay <= 24'd0;
                state <= state_back;
            end else begin
                cnt_delay <= cnt_delay + 1'b1;
            end
        end
        
        default: state <= IDLE;
    endcase
end

endmodule