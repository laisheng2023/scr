module keyboard_music(
    input  clk,
    output reg [3:0] col,
    input  [3:0] row,
    output beep,
//    output reg [3:0] led,
    
    // ========== 输出给屏幕的信号 ==========
    output reg [3:0] selected_group,   // 当前选择的音组 (2-5)
    output reg [2:0] selected_note,    // 当前选择的音符 (1-7)
    output reg group_selected,         // 是否已选择音组 (1=已选)
    output reg note_selected,
    output reg [2:0] volume            // 当前音量 (0-5)
);

    // ========== 音符频率参数 ==========
    parameter C2=18'd206346, D2=18'd183876, E2=18'd163820, F2=18'd154624,
              G2=18'd137755, A2=18'd122727, B2=18'd109338;
    parameter C3=18'd103196, D3=18'd91938,  E3=18'd81910,  F3=18'd77312,
              G3=18'd68877,  A3=18'd61364,  B3=18'd54669;
    parameter C4=18'd51598,  D4=18'd45969,  E4=18'd40955,  F4=18'd38656,
              G4=18'd34439,  A4=18'd30682,  B4=18'd27335;
    parameter C5=18'd25799,  D5=18'd22985,  E5=18'd20478,  F5=18'd19328,
              G5=18'd17219,  A5=18'd15341,  B5=18'd13667;
    parameter SILENCE = 18'd0;

    // ========== 键盘扫描 ==========
    reg [1:0] scan_cnt;
    reg [19:0] delay_cnt;
    reg [3:0] col_reg, row_reg;
    reg key_detected, key_detected_last;
    reg [3:0] raw_key;
    
    // ========== 播放控制 ==========
    reg playing;
    reg [25:0] tone_timer;
    reg [17:0] play_freq;
    reg [17:0] current_freq;
    reg [17:0] count, count1;
    reg beep_r;
    
    // ========== PWM音量控制 ==========
    reg [2:0] volume_reg;      // 当前音量值 0-5
    reg [9:0] pwm_counter;     // PWM计数器 (0-1023)
    reg pwm_out;               // PWM输出
    
    parameter TONE_DURATION = 26'd13500000;  // 500ms
    assign beep = pwm_out;
    
    // ========== 列扫描 ==========
    always @(posedge clk) begin
        delay_cnt <= delay_cnt + 1;
        if(delay_cnt == 20'd270000) begin
            delay_cnt <= 0;
            scan_cnt <= scan_cnt + 1;
            case(scan_cnt)
                2'd0: col <= 4'b1110;
                2'd1: col <= 4'b1101;
                2'd2: col <= 4'b1011;
                2'd3: col <= 4'b0111;
            endcase
            col_reg <= col;
        end
    end
    
    // ========== 获取原始按键编码 ==========
    always @(posedge clk) begin
        row_reg <= row;
        
        case({scan_cnt, row_reg})
            // 第1行
            {2'd0, 4'b1110}: raw_key <= 4'b0000;  // 按键0
            {2'd1, 4'b1110}: raw_key <= 4'b1101;  // 按键D
            {2'd2, 4'b1110}: raw_key <= 4'b1110;  // 按键E
            {2'd3, 4'b1110}: raw_key <= 4'b1111;  // 按键F
            
            // 第2行
            {2'd0, 4'b1101}: raw_key <= 4'b0111;  // 按键7
            {2'd1, 4'b1101}: raw_key <= 4'b1100;  // 按键C
            {2'd2, 4'b1101}: raw_key <= 4'b1001;  // 按键9
            {2'd3, 4'b1101}: raw_key <= 4'b1000;  // 按键8
            
            // 第3行
            {2'd0, 4'b1011}: raw_key <= 4'b0100;  // 按键4
            {2'd1, 4'b1011}: raw_key <= 4'b1011;  // 按键B
            {2'd2, 4'b1011}: raw_key <= 4'b0110;  // 按键6
            {2'd3, 4'b1011}: raw_key <= 4'b0101;  // 按键5
            
            // 第4行
            {2'd0, 4'b0111}: raw_key <= 4'b0001;  // 按键1
            {2'd1, 4'b0111}: raw_key <= 4'b1010;  // 按键A
            {2'd2, 4'b0111}: raw_key <= 4'b0011;  // 按键3
            {2'd3, 4'b0111}: raw_key <= 4'b0010;  // 按键2
            
            default: raw_key <= 4'b1111;
        endcase
        
        key_detected <= (row_reg != 4'b1111);
    end
    
    // ========== 音量初始化 ==========
    initial begin
        volume_reg <= 3'd3;  // 默认音量3（中等）
    end
    
    // ========== 核心逻辑 ==========
    always @(posedge clk) begin
        if(key_detected && !key_detected_last) begin
            case(raw_key)
                // ========== 音组选择（A,B,C,D）==========
                4'b1010: begin  // 物理按键A → 音组2
                    selected_group <= 4'd2;
                    group_selected <= 1'b1;
                end
                4'b1011: begin  // 物理按键B → 音组3
                    selected_group <= 4'd3;
                    group_selected <= 1'b1;
                end
                4'b1100: begin  // 物理按键C → 音组4
                    selected_group <= 4'd4;
                    group_selected <= 1'b1;
                end
                4'b1101: begin  // 物理按键D → 音组5
                    selected_group <= 4'd5;
                    group_selected <= 1'b1;
                end
                
                // ========== 音量控制（按键8增加，按键9减少）==========
                4'b1000: begin  // 按键8 → 音量+1
                    if(volume_reg < 3'd5) begin
                        volume_reg <= (volume_reg + 1'b1) % 6;
                    end
                end
                4'b1001: begin  // 按键9 → 音量-1
                    if(volume_reg > 3'd0) begin
                        volume_reg <= (volume_reg - 1'b1) %6;
                    end
                end
                
                // ========== 音阶播放（1,2,3,4,5,6,7）==========
                4'b0001: begin  // 按键1 → Do
                    selected_note <= 3'd1;
                    note_selected <= 1'b1; 
                    if(group_selected) begin
                        playing <= 1'b1;
                        tone_timer <= TONE_DURATION;
                        play_freq <= get_freq(selected_group, 3'd1);
                    end
                end
                4'b0010: begin  // 按键2 → Re
                    selected_note <= 3'd2;
                    note_selected <= 1'b1; 
                    if(group_selected) begin
                        playing <= 1'b1;
                        tone_timer <= TONE_DURATION;
                        play_freq <= get_freq(selected_group, 3'd2);
                    end
                end
                4'b0011: begin  // 按键3 → Mi
                    selected_note <= 3'd3;
                    note_selected <= 1'b1; 
                    if(group_selected) begin
                        playing <= 1'b1;
                        tone_timer <= TONE_DURATION;
                        play_freq <= get_freq(selected_group, 3'd3);
                    end
                end
                4'b0100: begin  // 按键4 → Fa
                    selected_note <= 3'd4;
                    note_selected <= 1'b1; 
                    if(group_selected) begin
                        playing <= 1'b1;
                        tone_timer <= TONE_DURATION;
                        play_freq <= get_freq(selected_group, 3'd4);
                    end
                end
                4'b0101: begin  // 按键5 → Sol
                    selected_note <= 3'd5;
                    note_selected <= 1'b1; 
                    if(group_selected) begin
                        playing <= 1'b1;
                        tone_timer <= TONE_DURATION;
                        play_freq <= get_freq(selected_group, 3'd5);
                    end
                end
                4'b0110: begin  // 按键6 → La
                    selected_note <= 3'd6;
                    note_selected <= 1'b1; 
                    if(group_selected) begin
                        playing <= 1'b1;
                        tone_timer <= TONE_DURATION;
                        play_freq <= get_freq(selected_group, 3'd6);
                    end
                end
                4'b0111: begin  // 按键7 → Si
                    selected_note <= 3'd7;
                    note_selected <= 1'b1; 
                    if(group_selected) begin
                        playing <= 1'b1;
                        tone_timer <= TONE_DURATION;
                        play_freq <= get_freq(selected_group, 3'd7);
                    end
                end
                
                // ========== 清除（F键）==========
                4'b1111: begin  // 物理按键F → 清除
                    group_selected <= 1'b0;
                    note_selected <= 1'b0;
                    playing <= 1'b0;
                end
                
                default: ;
            endcase
        end
        
        key_detected_last <= key_detected;
        
        // 播放持续时间控制
        if(playing) begin
            if(tone_timer > 0) begin
                tone_timer <= tone_timer - 1'b1;
                current_freq <= play_freq;
            end else begin
                playing <= 1'b0;
                current_freq <= SILENCE;
            end
        end else begin
            current_freq <= SILENCE;
        end
        
        // 音量值输出到端口
        volume <= volume_reg;
    end
    
    // ========== 频率查找函数 ==========
    function [17:0] get_freq;
        input [3:0] group;
        input [2:0] note;
        begin
            case({group, note})
                {4'd2,3'd1}: get_freq=C2; {4'd2,3'd2}: get_freq=D2;
                {4'd2,3'd3}: get_freq=E2; {4'd2,3'd4}: get_freq=F2;
                {4'd2,3'd5}: get_freq=G2; {4'd2,3'd6}: get_freq=A2;
                {4'd2,3'd7}: get_freq=B2;
                
                {4'd3,3'd1}: get_freq=C3; {4'd3,3'd2}: get_freq=D3;
                {4'd3,3'd3}: get_freq=E3; {4'd3,3'd4}: get_freq=F3;
                {4'd3,3'd5}: get_freq=G3; {4'd3,3'd6}: get_freq=A3;
                {4'd3,3'd7}: get_freq=B3;
                
                {4'd4,3'd1}: get_freq=C4; {4'd4,3'd2}: get_freq=D4;
                {4'd4,3'd3}: get_freq=E4; {4'd4,3'd4}: get_freq=F4;
                {4'd4,3'd5}: get_freq=G4; {4'd4,3'd6}: get_freq=A4;
                {4'd4,3'd7}: get_freq=B4;
                
                {4'd5,3'd1}: get_freq=C5; {4'd5,3'd2}: get_freq=D5;
                {4'd5,3'd3}: get_freq=E5; {4'd5,3'd4}: get_freq=F5;
                {4'd5,3'd5}: get_freq=G5; {4'd5,3'd6}: get_freq=A5;
                {4'd5,3'd7}: get_freq=B5;
                default: get_freq=SILENCE;
            endcase
        end
    endfunction
    
    // ========== 方波生成 ==========
    always @(posedge clk) begin
        if(current_freq != SILENCE) begin
            count <= count + 1'b1;
            if(count == count1) begin
                count <= 17'd0;
                beep_r <= ~beep_r;
            end
        end else begin
            count <= 17'd0;
            beep_r <= 1'b0;
        end
    end
    
    always @(posedge clk) begin
        count1 <= current_freq;
    end
    
    // ========== PWM音量调节（占空比方式）==========
    // PWM频率 = 主时钟 / 1024
    // 通过改变占空比来调节有效功率，从而控制音量
    always @(posedge clk) begin
        pwm_counter <= pwm_counter + 1'b1;  // 0 → 1023 → 0
        
        case(volume_reg)
            3'd0: pwm_out <= 1'b0;                              // 占空比 0%  静音
            3'd1: pwm_out <= (pwm_counter < 10'd102) ? beep_r : 1'b0;   // 占空比 10%
            3'd2: pwm_out <= (pwm_counter < 10'd256) ? beep_r : 1'b0;   // 占空比 25%
            3'd3: pwm_out <= (pwm_counter < 10'd512) ? beep_r : 1'b0;   // 占空比 50%  中等
            3'd4: pwm_out <= (pwm_counter < 10'd768) ? beep_r : 1'b0;   // 占空比 75%
            3'd5: pwm_out <= beep_r;                              // 占空比 100% 最大音量
            default: pwm_out <= beep_r;
        endcase
    end

endmodule