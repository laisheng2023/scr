module top(
    input  clk_27m,
    
    // 键盘接口
    output [3:0] col,
    input  [3:0] row,
    
    // 蜂鸣器
    output beep,
    
    // 屏幕接口
    output cs,
    output dc,
    output scl,
    output sda,
    output rst
);

    // 连接线
    wire [3:0] selected_group;
    wire [2:0] selected_note;
    wire group_selected;
    wire note_selected;
    
    // 实例化键盘模块
    keyboard_music keyboard_inst(
        .clk(clk_27m),
        .col(col),
        .row(row),
        .beep(beep),
        .selected_group(selected_group),
        .selected_note(selected_note),
        .group_selected(group_selected),
        .note_selected(note_selected)
    );
    
    // 实例化屏幕驱动模块
    lcd_driver lcd_inst(
        .clk(clk_27m),
        .group(selected_group),     // 连接键盘的音组
        .note(selected_note),        // 连接键盘的音符
        .group_valid(group_selected), // 连接键盘的标志
        .note_valid(note_selected),
        .cs(cs),
        .dc(dc),
        .scl(scl),
        .sda(sda),
        .rst(rst)
    );

endmodule