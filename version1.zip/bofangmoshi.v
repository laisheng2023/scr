module bofangmoshi(
    input  clk_27m,
    output cs,
    output dc,
    output scl,
    output sda,
    output rst
);

// ========== 参数 ==========
localparam LCD_W = 8'd132;
localparam LCD_H = 8'd162;

localparam COLOR_RED   = 16'hF800;
localparam COLOR_WHITE = 16'hFFFF;
localparam COLOR_BLUE  = 16'h001F;
localparam COLOR_GREEN = 16'h07E0;

localparam IDLE  = 4'd0;
localparam MAIN  = 4'd1;
localparam INIT  = 4'd2;
localparam SCAN  = 4'd3;
localparam WRITE = 4'd4;
localparam DELAY = 4'd5;

localparam LOW  = 1'b0;
localparam HIGH = 1'b1;

// ========== 寄存器 ==========
reg [3:0] state;
reg [3:0] state_back;

reg [7:0] x_cnt;
reg [7:0] y_cnt;
reg [5:0] cnt_write;
reg [23:0] cnt_delay;
reg [23:0] num_delay;
reg [15:0] cnt;
reg [2:0] cnt_main;
reg [2:0] cnt_init;
reg [3:0] cnt_scan;
reg [8:0] data_reg;
reg high_word;
reg [1:0] clk_div;

reg cs_r;
reg dc_r;
reg scl_r;
reg sda_r;
reg rst_r;

reg show_pixel;

wire clk_spi;
assign clk_spi = clk_div[1];

// ========== 点阵存储 (16行 x 32列) ==========

   
// ========== 初始化命令 ==========
reg [8:0] reg_init [0:5];
reg [8:0] reg_setxy [0:10];


// ========== 点阵数据 ==========
// ========== 点阵存储 (132行 x 80列 = 10字节/行) ==========
reg [0:63] bofangmoshi [0:15];
reg [0:63] zhuangtai [0:15];
reg [0:127] kongzhi [0:15];
reg [0:63] yinliang [0:15];
reg [0:127] yljj [0:15];
reg [0:127] fanhui [0:15];
// ========== 点阵数据 ==========
// ========== 点阵播放模式数据 (16行 x 64列) ==========
initial begin
    bofangmoshi[0]  = 64'h2078204011100048;
    bofangmoshi[1]  = 64'h27c0104011100044;
    bofangmoshi[2]  = 64'h2248004017fc0044;
    bofangmoshi[3]  = 64'h2150fe8011100040;
    bofangmoshi[4]  = 64'hfbfc20fefc00fffe;
    bofangmoshi[5]  = 64'h2150210813f80040;
    bofangmoshi[6]  = 64'h22483e8832080040;
    bofangmoshi[7]  = 64'h2c0624883bf83e40;
    bofangmoshi[8]  = 64'h33f8248856080840;
    bofangmoshi[9]  = 64'he248245053f80840;
    bofangmoshi[10] = 64'h2248245090400820;
    bofangmoshi[11] = 64'h23f8242017fc0822;
    bofangmoshi[12] = 64'h2248445010a00f12;
    bofangmoshi[13] = 64'h224854881110780a;
    bofangmoshi[14] = 64'ha3f8890412082006;
    bofangmoshi[15] = 64'h4208020214060002;
end
// ========== 点阵状态数据 (16行 x 64列) ==========
initial begin
    zhuangtai[0]  = 64'h0840010000000000;
    zhuangtai[1]  = 64'h0848010000000000;
    zhuangtai[2]  = 64'h08447ffc00000000;
    zhuangtai[3]  = 64'h4844010000000000;
    zhuangtai[4]  = 64'h2840028000000000;
    zhuangtai[5]  = 64'h2ffe044000000000;
    zhuangtai[6]  = 64'h08400a2000000000;
    zhuangtai[7]  = 64'h0840311800000000;
    zhuangtai[8]  = 64'h1840c00600000000;
    zhuangtai[9]  = 64'h28a0010030000000;
    zhuangtai[10] = 64'hc8a0088830000000;
    zhuangtai[11] = 64'h0890488400000000;
    zhuangtai[12] = 64'h0910481230000000;
    zhuangtai[13] = 64'h0908481230000000;
    zhuangtai[14] = 64'h0a0487f000000000;
    zhuangtai[15] = 64'h0c02000000000000;
end
// ========== 点阵音量数据 (16行 x 64列) ==========
initial begin
    yinliang[0]  = 64'h0200000000000000;
    yinliang[1]  = 64'h01001ff000000000;
    yinliang[2]  = 64'h3ff8101000000000;
    yinliang[3]  = 64'h00001ff000000000;
    yinliang[4]  = 64'h0820101000000000;
    yinliang[5]  = 64'h0440fffe00000000;
    yinliang[6]  = 64'hfffe000000000000;
    yinliang[7]  = 64'h00001ff000000000;
    yinliang[8]  = 64'h1ff0111000000000;
    yinliang[9]  = 64'h10101ff030000000;
    yinliang[10] = 64'h1010111030000000;
    yinliang[11] = 64'h1ff01ff000000000;
    yinliang[12] = 64'h1010010030000000;
    yinliang[13] = 64'h10101ff030000000;
    yinliang[14] = 64'h1ff0010000000000;
    yinliang[15] = 64'h10107ffc00000000;
end
// ========== 点阵控制数据 (16行 x 128列) ==========
initial begin
    kongzhi[0]  = 128'h00002078204000000000100c10800000;
    kongzhi[1]  = 128'h000027c0104000000000fef010400000;
    kongzhi[2]  = 128'h00002248004000000000208017fc0000;
    kongzhi[3]  = 128'h10002150fe800000f800488020000000;
    kongzhi[4]  = 128'h1000fbfc20fe000044007efe23f80000;
    kongzhi[5]  = 128'h18002150210800004400088862080000;
    kongzhi[6]  = 128'h280022483e88000044000e8863f80000;
    kongzhi[7]  = 128'h28002c06248800007800f908a0000000;
    kongzhi[8]  = 128'h240033f82488000044004a082ffe0000;
    kongzhi[9]  = 128'h3c00e2482450000042001ff828020000;
    kongzhi[10] = 128'h44002248245000004200101023f80000;
    kongzhi[11] = 128'h420023f8242000004200101020400000;
    kongzhi[12] = 128'h420022484450000044001ff020400000;
    kongzhi[13] = 128'he700224854880000f800101020400000;
    kongzhi[14] = 128'h0000a3f8890400000000101021400000;
    kongzhi[15] = 128'h000042080202000000001ff020800000;
end

// ========== 点阵音量加减数据 (16行 x 128列) ==========
initial begin
    yljj[0]  = 128'h00000200000000000000020000000000;
    yljj[1]  = 128'h00000100000000000000010000000000;
    yljj[2]  = 128'h00003ff80000000000003ff800000000;
    yljj[3]  = 128'h3e00000000000000f800000000000000;
    yljj[4]  = 128'h42000820000000004400082000000000;
    yljj[5]  = 128'h42000440080000004200044000000000;
    yljj[6]  = 128'h8000fffe080000004200fffe00000000;
    yljj[7]  = 128'h80000000080000004200000000000000;
    yljj[8]  = 128'h80001ff07f00000042001ff07e000000;
    yljj[9]  = 128'h80001010080000004200101000000000;
    yljj[10] = 128'h80001010080000004200101000000000;
    yljj[11] = 128'h42001ff00800000042001ff000000000;
    yljj[12] = 128'h44001010000000004400101000000000;
    yljj[13] = 128'h3800101000000000f800101000000000;
    yljj[14] = 128'h00001ff00000000000001ff000000000;
    yljj[15] = 128'h00001010000000000000101000000000;
end

// ========== 点阵返回数据 (16行 x 128列) ==========
initial begin
    fanhui[0]  = 128'h00000008000000000000100000200000;
    fanhui[1]  = 128'h0000203c3ff8000000001000ff200000;
    fanhui[2]  = 128'h000013c020080000000011fc02200000;
    fanhui[3]  = 128'hfc00120020080000fc0010447a7e0000;
    fanhui[4]  = 128'h4200020027c80000420010444a420000;
    fanhui[5]  = 128'h480003fc2448000048001e447a840000;
    fanhui[6]  = 128'h4800f204244800004800f04400100000;
    fanhui[7]  = 128'h780012882448000078001044ff100000;
    fanhui[8]  = 128'h48001250244800004800104402100000;
    fanhui[9]  = 128'h4800122024480000480012447a100000;
    fanhui[10] = 128'h4000125027c80000400014444a280000;
    fanhui[11] = 128'h4000148820080000420018844a280000;
    fanhui[12] = 128'h4000150420080000420010847a280000;
    fanhui[13] = 128'he00028003ff80000fc00010402440000;
    fanhui[14] = 128'h000047fe20080000000002280a440000;
    fanhui[15] = 128'h00000000000000000000041004820000;
end

// ========== 初始化命令 ==========
integer j;
initial begin
    // 初始化命令
    reg_init[0] = {1'b0, 8'h11};  // 退出睡眠
    reg_init[1] = {1'b0, 8'h3a};  // 像素格式
    reg_init[2] = {1'b1, 8'h05};  // 16位色
    reg_init[3] = {1'b0, 8'h36};  // 内存访问控制
    reg_init[4] = {1'b1, 8'h80};  // 设置
    reg_init[5] = {1'b0, 8'h29};  // 开启显示
    
    // 显示区域
    reg_setxy[0]  = {1'b0, 8'h2a};  // 列地址
    reg_setxy[1]  = {1'b1, 8'h00};
    reg_setxy[2]  = {1'b1, 8'h00};
    reg_setxy[3]  = {1'b1, 8'h00};
    reg_setxy[4]  = {1'b1, 8'd131};
    reg_setxy[5]  = {1'b0, 8'h2b};  // 行地址
    reg_setxy[6]  = {1'b1, 8'h00};
    reg_setxy[7]  = {1'b1, 8'h00};
    reg_setxy[8]  = {1'b1, 8'h00};
    reg_setxy[9]  = {1'b1, 8'd161};
    reg_setxy[10] = {1'b0, 8'h2c};  // 写内存
end

// 状态机初始值
initial begin
    state = IDLE;
    state_back = IDLE;
    x_cnt = 8'd0;
    y_cnt = 8'd0;
    cnt_write = 6'd0;
    cnt_delay = 24'd0;
    num_delay = 24'd0;
    cnt = 16'd0;
    cnt_main = 3'd0;
    cnt_init = 3'd0;
    cnt_scan = 4'd0;
    data_reg = 9'd0;
    high_word = 1'b1;
    clk_div = 2'd0;
    cs_r = 1'b1;
    dc_r = 1'b1;
    scl_r = 1'b1;
    sda_r = 1'b1;
    rst_r = 1'b0;
    show_pixel = 1'b0;
end

assign cs = cs_r;
assign dc = dc_r;
assign scl = scl_r;
assign sda = sda_r;
assign rst = rst_r;

// ========== 时钟分频 ==========
always @(posedge clk_27m) begin
    clk_div <= clk_div + 1'b1;
end

// ========== 主状态机 ==========
always @(posedge clk_spi) begin
    case(state)
        IDLE: begin
            x_cnt <= 8'd0;
            y_cnt <= 8'd0;
            cnt_main <= 3'd0;
            cnt_init <= 3'd0;
            cnt_scan <= 4'd0;
            high_word <= 1'b1;
            cnt <= 16'd0;
            cnt_write <= 6'd0;
            cnt_delay <= 24'd0;
            cs_r <= 1'b1;
            scl_r <= 1'b1;
            rst_r <= 1'b1;
            state <= MAIN;
            state_back <= MAIN;
        end
        
        MAIN: begin
            case(cnt_main)
                3'd0: begin state <= INIT; cnt_main <= cnt_main + 1'b1; end
                3'd1: begin state <= SCAN; cnt_main <= cnt_main + 1'b1; end
                3'd2: begin cnt_main <= 3'd1; end
                default: cnt_main <= 3'd0;
            endcase
        end
        
        INIT: begin
            case(cnt_init)
                3'd0: begin
                    num_delay <= 24'd500000;
                    state <= DELAY;
                    state_back <= INIT;
                    cnt_init <= cnt_init + 1'b1;
                end
                3'd1: begin
                    if(cnt >= 6) begin
                        cnt <= 16'd0;
                        cnt_init <= cnt_init + 1'b1;
                    end else begin
                        data_reg <= reg_init[cnt];
                        num_delay <= 24'd5000;
                        cnt <= cnt + 1;
                        state <= WRITE;
                        state_back <= INIT;
                    end
                end
                3'd2: begin
                    cnt_init <= 3'd0;
                    state <= MAIN;
                end
                default: cnt_init <= 3'd0;
            endcase
        end
        
        SCAN: begin
            case(cnt_scan)
                4'd0: begin
                    if(cnt >= 11) begin
                        cnt <= 16'd0;
                        cnt_scan <= cnt_scan + 1'b1;
                    end else begin
                        data_reg <= reg_setxy[cnt];
                        cnt <= cnt + 1;
                        num_delay <= 24'd1000;
                        state <= WRITE;
                        state_back <= SCAN;
                    end
                end
                
                // ========== 点阵显示 - 顶部居中 ==========
                4'd1: begin
                    show_pixel = 1'b0;
                    // Y范围: 10-25 (16行), X范围: 50-81 (32列)
                    if(y_cnt >= 5 && y_cnt <= 20 && x_cnt >= 34 && x_cnt <= 97) begin
                        if(bofangmoshi[y_cnt-5][ (x_cnt-34)]) show_pixel = 1'b1;
                    end
                    
                    else if(y_cnt >= 22 && y_cnt <= 37 && x_cnt >= 67 && x_cnt <= 130) begin
                        if(zhuangtai[y_cnt-22][ (x_cnt-67)]) show_pixel = 1'b1;
                    end

                    else if(y_cnt >= 39 && y_cnt <= 54 && x_cnt >= 67 && x_cnt <= 130) begin
                        if(yinliang[y_cnt-39][ (x_cnt-67)]) show_pixel = 1'b1;
                    end

                    else if(y_cnt >= 107 && y_cnt <= 122 && x_cnt >= 2 && x_cnt <= 129) begin
                        if(kongzhi[y_cnt-107][ (x_cnt-2)]) show_pixel = 1'b1;
                    end

                    else if(y_cnt >= 124 && y_cnt <= 139 && x_cnt >= 2 && x_cnt <= 129) begin
                        if(yljj[y_cnt-124][ (x_cnt-2)]) show_pixel = 1'b1;
                    end

                    else if(y_cnt >= 141 && y_cnt <= 156 && x_cnt >= 2 && x_cnt <= 129) begin
                        if(fanhui[y_cnt-141][ (x_cnt-2)]) show_pixel = 1'b1;
                    end
                    if(show_pixel) begin
                        data_reg <= {1'b1, COLOR_RED[15:8]};  // 红色
                    end else begin
                        data_reg <= {1'b1, COLOR_WHITE[15:8]};  // 白色背景
                    end
                    num_delay <= 24'd100;
                    state <= WRITE;
                    state_back <= SCAN;
                    cnt_scan <= cnt_scan + 1'b1;
                end
                
                4'd2: begin  // 点阵低字节
                    if(high_word) begin
                        if(show_pixel) begin
                            data_reg <= {1'b1, COLOR_RED[7:0]};
                        end else begin
                            data_reg <= {1'b1, COLOR_WHITE[7:0]};
                        end
                        num_delay <= 24'd100;
                        state <= WRITE;
                        state_back <= SCAN;
                        high_word <= 1'b0;
                    end else begin
                        high_word <= 1'b1;
                        if(x_cnt >= LCD_W-1) begin
                            x_cnt <= 8'd0;
                            if(y_cnt >= LCD_H-1) begin
                                y_cnt <= 8'd0;
                                cnt_scan <= 4'd0;
                            end else begin
                                y_cnt <= y_cnt + 1'b1;
                                cnt_scan <= 4'd1;
                            end
                        end else begin
                            x_cnt <= x_cnt + 1'b1;
                            cnt_scan <= 4'd1;
                        end
                    end
                end
                
                default: cnt_scan <= 4'd0;
            endcase
        end
        
        WRITE: begin
            if(cnt_write >= 6'd17) begin
                cnt_write <= 6'd0;
                state <= DELAY;
            end else begin
                cnt_write <= cnt_write + 1'b1;
            end
            cs_r <= 1'b0;
            case(cnt_write)
                6'd0:  dc_r <= data_reg[8];
                6'd1:  begin scl_r <= LOW; sda_r <= data_reg[7]; end
                6'd2:  scl_r <= HIGH;
                6'd3:  begin scl_r <= LOW; sda_r <= data_reg[6]; end
                6'd4:  scl_r <= HIGH;
                6'd5:  begin scl_r <= LOW; sda_r <= data_reg[5]; end
                6'd6:  scl_r <= HIGH;
                6'd7:  begin scl_r <= LOW; sda_r <= data_reg[4]; end
                6'd8:  scl_r <= HIGH;
                6'd9:  begin scl_r <= LOW; sda_r <= data_reg[3]; end
                6'd10: scl_r <= HIGH;
                6'd11: begin scl_r <= LOW; sda_r <= data_reg[2]; end
                6'd12: scl_r <= HIGH;
                6'd13: begin scl_r <= LOW; sda_r <= data_reg[1]; end
                6'd14: scl_r <= HIGH;
                6'd15: begin scl_r <= LOW; sda_r <= data_reg[0]; end
                6'd16: scl_r <= HIGH;
                6'd17: scl_r <= LOW;
                default: begin end
            endcase
        end
        
        DELAY: begin
            cs_r <= 1'b1;
            if(cnt_delay >= num_delay) begin
                cnt_delay <= 24'd0;
                state <= state_back;
            end else begin
                cnt_delay <= cnt_delay + 1'b1;
            end
        end
        
        default: state <= IDLE;
    endcase
end

endmodule