`timescale 1ns / 1ps

module top(
    input clk_27m,           // 27MHz时钟
    output [3:0] col,    // 矩阵键盘列输出
    input [3:0] row,         // 矩阵键盘行输入
    output beep,             // 蜂鸣器输出
    
    // 屏幕接口
    output cs,
    output dc,
    output scl,
    output sda,
    output rst
);

    // ========== 音乐选择信号 ==========
    wire [1:0] music_select;
    
    // ========== 键盘扫描相关寄存器 ==========
    reg [1:0] scan_cnt;
    reg [19:0] delay_cnt;
    reg [3:0] row_reg;
    reg [3:0] raw_key;
    reg key_detected, key_detected_last;
    
    // ========== 实例化播放功能模块 ==========
    play_music u_play_music(
        .clk_27m(clk_27m),
        .col(col),
        .row(row),
        .beep(beep)
    );
    
    // ========== 实例化播放页面屏幕模块 ==========
    bofangmoshi u_bofangmoshi(
        .clk_27m(clk_27m),
        .cs(cs),
        .dc(dc),
        .scl(scl),
        .sda(sda),
        .rst(rst)
    );

endmodule