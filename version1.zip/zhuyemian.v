module top(
    input  clk_27m,
    output cs,
    output dc,
    output scl,
    output sda,
    output rst
);

// ========== 参数 ==========
localparam LCD_W = 8'd132;
localparam LCD_H = 8'd162;

localparam COLOR_RED   = 16'hF800;
localparam COLOR_WHITE = 16'hFFFF;
localparam COLOR_BLUE  = 16'h001F;
localparam COLOR_GREEN = 16'h07E0;

localparam IDLE  = 4'd0;
localparam MAIN  = 4'd1;
localparam INIT  = 4'd2;
localparam SCAN  = 4'd3;
localparam WRITE = 4'd4;
localparam DELAY = 4'd5;

localparam LOW  = 1'b0;
localparam HIGH = 1'b1;

// ========== 寄存器 ==========
reg [3:0] state;
reg [3:0] state_back;

reg [7:0] x_cnt;
reg [7:0] y_cnt;
reg [5:0] cnt_write;
reg [23:0] cnt_delay;
reg [23:0] num_delay;
reg [15:0] cnt;
reg [2:0] cnt_main;
reg [2:0] cnt_init;
reg [3:0] cnt_scan;
reg [8:0] data_reg;
reg high_word;
reg [1:0] clk_div;

reg cs_r;
reg dc_r;
reg scl_r;
reg sda_r;
reg rst_r;

reg show_pixel;

wire clk_spi;
assign clk_spi = clk_div[1];

// ========== 点阵存储 (16行 x 32列) ==========

   
// ========== 初始化命令 ==========
reg [8:0] reg_init [0:5];
reg [8:0] reg_setxy [0:10];


// ========== 点阵数据 ==========
// ========== 点阵存储 (132行 x 80列 = 10字节/行) ==========
reg [63:0] bitmap1 [0:15];
reg [0:127] bitmap2 [0:15];   
reg [0:127] bitmap3 [0:15];

// ========== 点阵数据 ==========
initial begin
    bitmap1[0]  = 64'h0100020000200100;
    bitmap1[1]  = 64'h0100010000f00280;
    bitmap1[2]  = 64'h01003ff81f000c60;
    bitmap1[3]  = 64'h0100000010003018;
    bitmap1[4]  = 64'h010008201100cfe6;
    bitmap1[5]  = 64'h1110044021000000;
    bitmap1[6]  = 64'h1108fffe21001ff0;
    bitmap1[7]  = 64'h110400003ffc1010;
    bitmap1[8]  = 64'h21041ff001001ff0;
    bitmap1[9]  = 64'h2102101009200000;
    bitmap1[10] = 64'h4102101009103ff8;
    bitmap1[11] = 64'h81021ff011082448;
    bitmap1[12] = 64'h0100101021042448;
    bitmap1[13] = 64'h0100101041042448;
    bitmap1[14] = 64'h05001ff00500fffe;
    bitmap1[15] = 64'h0200101002000000;
end
initial begin
bitmap2[0]  = 128'h0000000080010011100048000000;
bitmap2[1]  = 128'h0000002040010011100044000000;
bitmap2[2]  = 128'h00000017fc7ffc17fc0044000000;
bitmap2[3]  = 128'h0010001404010011100040000000;
bitmap2[4]  = 128'h00100080003ff8fc00fffe000000;
bitmap2[5]  = 128'h00180043f8020013f80040000000;
bitmap2[6]  = 128'h0028004040fffe32080040000000;
bitmap2[7]  = 128'h00280013f804403bf83e40000000;
bitmap2[8]  = 128'h0024001248082056080840000000;
bitmap2[9]  = 128'h003c0023f837d853f80840000000;
bitmap2[10] = 128'h004400e248c10690400820000000;
bitmap2[11] = 128'h00420023f81ff017fc0822000000;
bitmap2[12] = 128'h0042002000010010a00f12000000;
bitmap2[13] = 128'h00e700211002c01110780a000000;
bitmap2[14] = 128'h00000022080c3012082006000000;
bitmap2[15] = 128'h0000000404300814060002000000;
end
initial begin
bitmap3[0]  = 128'h0000002078204011100048000000;
bitmap3[1]  = 128'h00000027c0104011100044000000;
bitmap3[2]  = 128'h0000002248004017fc0044000000;
bitmap3[3]  = 128'h00f8002150fe8011100040000000;
bitmap3[4]  = 128'h004400fbfc20fefc00fffe000000;
bitmap3[5]  = 128'h0044002150210813f80040000000;
bitmap3[6]  = 128'h00440022483e8832080040000000;
bitmap3[7]  = 128'h0078002c0624883bf83e40000000;
bitmap3[8]  = 128'h00440033f8248856080840000000;
bitmap3[9]  = 128'h004200e248245053f80840000000;
bitmap3[10] = 128'h0042002248245090400820000000;
bitmap3[11] = 128'h00420023f8242017fc0822000000;
bitmap3[12] = 128'h0044002248445010a00f12000000;
bitmap3[13] = 128'h00f800224854881110780a000000;
bitmap3[14] = 128'h000000a3f8890412082006000000;
bitmap3[15] = 128'h0000004208020214060002000000;
end

// ========== 初始化命令 ==========
integer j;
initial begin
    // 初始化命令
    reg_init[0] = {1'b0, 8'h11};  // 退出睡眠
    reg_init[1] = {1'b0, 8'h3a};  // 像素格式
    reg_init[2] = {1'b1, 8'h05};  // 16位色
    reg_init[3] = {1'b0, 8'h36};  // 内存访问控制
    reg_init[4] = {1'b1, 8'h80};  // 设置
    reg_init[5] = {1'b0, 8'h29};  // 开启显示
    
    // 显示区域
    reg_setxy[0]  = {1'b0, 8'h2a};  // 列地址
    reg_setxy[1]  = {1'b1, 8'h00};
    reg_setxy[2]  = {1'b1, 8'h00};
    reg_setxy[3]  = {1'b1, 8'h00};
    reg_setxy[4]  = {1'b1, 8'd131};
    reg_setxy[5]  = {1'b0, 8'h2b};  // 行地址
    reg_setxy[6]  = {1'b1, 8'h00};
    reg_setxy[7]  = {1'b1, 8'h00};
    reg_setxy[8]  = {1'b1, 8'h00};
    reg_setxy[9]  = {1'b1, 8'd161};
    reg_setxy[10] = {1'b0, 8'h2c};  // 写内存
end

// 状态机初始值
initial begin
    state = IDLE;
    state_back = IDLE;
    x_cnt = 8'd0;
    y_cnt = 8'd0;
    cnt_write = 6'd0;
    cnt_delay = 24'd0;
    num_delay = 24'd0;
    cnt = 16'd0;
    cnt_main = 3'd0;
    cnt_init = 3'd0;
    cnt_scan = 4'd0;
    data_reg = 9'd0;
    high_word = 1'b1;
    clk_div = 2'd0;
    cs_r = 1'b1;
    dc_r = 1'b1;
    scl_r = 1'b1;
    sda_r = 1'b1;
    rst_r = 1'b0;
    show_pixel = 1'b0;
end

assign cs = cs_r;
assign dc = dc_r;
assign scl = scl_r;
assign sda = sda_r;
assign rst = rst_r;

// ========== 时钟分频 ==========
always @(posedge clk_27m) begin
    clk_div <= clk_div + 1'b1;
end

// ========== 主状态机 ==========
always @(posedge clk_spi) begin
    case(state)
        IDLE: begin
            x_cnt <= 8'd0;
            y_cnt <= 8'd0;
            cnt_main <= 3'd0;
            cnt_init <= 3'd0;
            cnt_scan <= 4'd0;
            high_word <= 1'b1;
            cnt <= 16'd0;
            cnt_write <= 6'd0;
            cnt_delay <= 24'd0;
            cs_r <= 1'b1;
            scl_r <= 1'b1;
            rst_r <= 1'b1;
            state <= MAIN;
            state_back <= MAIN;
        end
        
        MAIN: begin
            case(cnt_main)
                3'd0: begin state <= INIT; cnt_main <= cnt_main + 1'b1; end
                3'd1: begin state <= SCAN; cnt_main <= cnt_main + 1'b1; end
                3'd2: begin cnt_main <= 3'd1; end
                default: cnt_main <= 3'd0;
            endcase
        end
        
        INIT: begin
            case(cnt_init)
                3'd0: begin
                    num_delay <= 24'd500000;
                    state <= DELAY;
                    state_back <= INIT;
                    cnt_init <= cnt_init + 1'b1;
                end
                3'd1: begin
                    if(cnt >= 6) begin
                        cnt <= 16'd0;
                        cnt_init <= cnt_init + 1'b1;
                    end else begin
                        data_reg <= reg_init[cnt];
                        num_delay <= 24'd5000;
                        cnt <= cnt + 1;
                        state <= WRITE;
                        state_back <= INIT;
                    end
                end
                3'd2: begin
                    cnt_init <= 3'd0;
                    state <= MAIN;
                end
                default: cnt_init <= 3'd0;
            endcase
        end
        
        SCAN: begin
            case(cnt_scan)
                4'd0: begin
                    if(cnt >= 11) begin
                        cnt <= 16'd0;
                        cnt_scan <= cnt_scan + 1'b1;
                    end else begin
                        data_reg <= reg_setxy[cnt];
                        cnt <= cnt + 1;
                        num_delay <= 24'd1000;
                        state <= WRITE;
                        state_back <= SCAN;
                    end
                end
                
                // ========== 点阵显示 - 顶部居中 ==========
                4'd1: begin
                    show_pixel = 1'b0;
                    // Y范围: 10-25 (16行), X范围: 50-81 (32列)
                    if(y_cnt >= 5 && y_cnt <= 20 && x_cnt >= 32 && x_cnt <= 95) begin
                        if(bitmap1[y_cnt-5][ (x_cnt-32)]) show_pixel = 1'b1;
                    end
                    
                    else if(y_cnt >= 50 && y_cnt <= 65 && x_cnt >= 0 && x_cnt <= 127) begin
                        if(bitmap2[y_cnt-50][ (x_cnt)]) show_pixel = 1'b1;
                    end

                    else if(y_cnt >= 100 && y_cnt <= 115 && x_cnt >= 0 && x_cnt <= 127) begin
                        if(bitmap3[y_cnt-100][ (x_cnt)]) show_pixel = 1'b1;
                    end

                    if(show_pixel) begin
                        data_reg <= {1'b1, COLOR_RED[15:8]};  // 红色
                    end else begin
                        data_reg <= {1'b1, COLOR_WHITE[15:8]};  // 白色背景
                    end
                    num_delay <= 24'd100;
                    state <= WRITE;
                    state_back <= SCAN;
                    cnt_scan <= cnt_scan + 1'b1;
                end
                
                4'd2: begin  // 点阵低字节
                    if(high_word) begin
                        if(show_pixel) begin
                            data_reg <= {1'b1, COLOR_RED[7:0]};
                        end else begin
                            data_reg <= {1'b1, COLOR_WHITE[7:0]};
                        end
                        num_delay <= 24'd100;
                        state <= WRITE;
                        state_back <= SCAN;
                        high_word <= 1'b0;
                    end else begin
                        high_word <= 1'b1;
                        if(x_cnt >= LCD_W-1) begin
                            x_cnt <= 8'd0;
                            if(y_cnt >= LCD_H-1) begin
                                y_cnt <= 8'd0;
                                cnt_scan <= 4'd0;
                            end else begin
                                y_cnt <= y_cnt + 1'b1;
                                cnt_scan <= 4'd1;
                            end
                        end else begin
                            x_cnt <= x_cnt + 1'b1;
                            cnt_scan <= 4'd1;
                        end
                    end
                end
                
                default: cnt_scan <= 4'd0;
            endcase
        end
        
        WRITE: begin
            if(cnt_write >= 6'd17) begin
                cnt_write <= 6'd0;
                state <= DELAY;
            end else begin
                cnt_write <= cnt_write + 1'b1;
            end
            cs_r <= 1'b0;
            case(cnt_write)
                6'd0:  dc_r <= data_reg[8];
                6'd1:  begin scl_r <= LOW; sda_r <= data_reg[7]; end
                6'd2:  scl_r <= HIGH;
                6'd3:  begin scl_r <= LOW; sda_r <= data_reg[6]; end
                6'd4:  scl_r <= HIGH;
                6'd5:  begin scl_r <= LOW; sda_r <= data_reg[5]; end
                6'd6:  scl_r <= HIGH;
                6'd7:  begin scl_r <= LOW; sda_r <= data_reg[4]; end
                6'd8:  scl_r <= HIGH;
                6'd9:  begin scl_r <= LOW; sda_r <= data_reg[3]; end
                6'd10: scl_r <= HIGH;
                6'd11: begin scl_r <= LOW; sda_r <= data_reg[2]; end
                6'd12: scl_r <= HIGH;
                6'd13: begin scl_r <= LOW; sda_r <= data_reg[1]; end
                6'd14: scl_r <= HIGH;
                6'd15: begin scl_r <= LOW; sda_r <= data_reg[0]; end
                6'd16: scl_r <= HIGH;
                6'd17: scl_r <= LOW;
                default: begin end
            endcase
        end
        
        DELAY: begin
            cs_r <= 1'b1;
            if(cnt_delay >= num_delay) begin
                cnt_delay <= 24'd0;
                state <= state_back;
            end else begin
                cnt_delay <= cnt_delay + 1'b1;
            end
        end
        
        default: state <= IDLE;
    endcase
end

endmodule